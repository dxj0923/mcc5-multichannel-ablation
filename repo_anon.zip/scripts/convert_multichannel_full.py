"""
Convert the timestamped raw output of experiment/run_multichannel_full.py
(experiment/results_full_YYYYmmdd_HHMMSS.json) into the shipped, table-ready
data/multichannel_full_results.json used by Table tab:confusion.

Transformation (previously an undocumented manual step; this script IS the
provenance record):
  - confusions: dict-of-counts {true: {pred: count}} -> list-of-fractions
    {true: [[pred, fraction], ...]}, where the self-prediction count is dropped
    and the remaining counts are normalized over the ERROR total, sorted desc.
  - elapsed_s -> time_seconds; the per-run 'seed' and 'timestamp' fields are
    dropped from the shipped file (seed is asserted to be 42, matching the
    hard-coded seed in run_multichannel_full.py and the table caption).
  - top-level '_meta' is dropped.

Usage (from repo root):
    python scripts/convert_multichannel_full.py [raw_json] [--out PATH]
Default input: the newest experiment/results_full_*.json.
"""
import json, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def main():
    args = [a for a in sys.argv[1:] if a != '--out']
    out_path = None
    if '--out' in sys.argv:
        i = sys.argv.index('--out')
        out_path = Path(sys.argv[i + 1])
        args = [a for a in args if a != sys.argv[i + 1]]
    if args:
        raw_path = Path(args[0])
    else:
        cands = sorted((ROOT / 'experiment').glob('results_full_*.json'))
        if not cands:
            raise SystemExit('No experiment/results_full_*.json found; pass a path explicitly.')
        raw_path = cands[-1]
    raw = json.loads(raw_path.read_text())
    print(f'Input: {raw_path.name}  (timestamp {raw.get("_meta", {}).get("timestamp", "?")})')

    out = {}
    for sc, entry in raw.items():
        if sc == '_meta':
            continue
        seed = entry.get('seed')
        assert seed == 42, f'{sc}: expected seed 42, got {seed}'
        conf_out = {}
        for true_cls, counts in entry['confusions'].items():
            err = {p: c for p, c in counts.items() if p != true_cls}
            total_err = sum(err.values())
            if total_err == 0:
                conf_out[true_cls] = []
            else:
                pairs = sorted(err.items(), key=lambda kv: -kv[1])
                conf_out[true_cls] = [[p, c / total_err] for p, c in pairs]
        out[sc] = {
            'best_acc': entry['best_acc'],
            'per_class': entry['per_class'],
            'confusions': conf_out,
            'time_seconds': entry['elapsed_s'],
        }

    dst = out_path or (ROOT / 'data' / 'multichannel_full_results.json')
    dst.write_text(json.dumps(out, indent=2))
    print(f'Wrote {dst} (seed=42 verified for all scenarios)')

if __name__ == '__main__':
    main()
