"""
Fig 2: Ablation — grouped bar chart across 4 scenarios x 6 configurations.
Multi-seed upgrade (2026-07-30, extended 2026-10-19): mean +/- std over n=5 seeds
(42/123/456/789/1011, 30 epochs, best-epoch).
Data source: data/multi_seed_results_full.json only — the raw
30-epoch runs now cover all 28 cells (140 entries = 28 cells x 5 seeds);
the legacy summary-only / single-run fallbacks were removed.
"""
from fig_common import *; style()
import json
from collections import defaultdict

CONFS = ['vib_Z','vib_XY','vib_XYZ','cur_ABC','vib_XYZ_curA','vibcur_6ch']
SCENS = ['leave_3000','leave_500','low_to_high','high_to_low']

# --- assemble mean/std from raw per-seed file (all cells present) ---
raw = json.loads((DATA / 'multi_seed_results_full.json').read_bytes())
g = defaultdict(list)
for e in raw:
    g[(e['scenario'], e['config'])].append(e['best_acc'])
missing = [(s, c) for s in SCENS for c in CONFS if (s, c) not in g]
assert not missing, f'missing cells in multi_seed_results_full.json: {missing}'

acc = np.zeros((6, 4)); std = np.zeros((6, 4))
for i, c in enumerate(CONFS):
    for j, s in enumerate(SCENS):
        cell = g[(s, c)]
        acc[i, j] = float(np.mean(cell))
        std[i, j] = float(np.std(cell, ddof=1)) if len(cell) > 1 else 0.0

fig, ax = plt.subplots(figsize=(7.0, 3.0))
x = np.arange(4); n = 6; bw = 0.12
off = np.linspace(-(n-1)*bw/2, (n-1)*bw/2, n)
cols = ['#0072B2','#D55E00','#009E73','#E69F00','#CC79A7','#333']
labs = ['vib$_Z$ (1)','vib$_{XY}$ (2)','vib$_{XYZ}$ (3)','cur$_{ABC}$ (3)','vib+cur$_A$ (4)','vibcur$_{6ch}$ (6)']

for i in range(n):
    bars = ax.bar(x+off[i], acc[i], bw, label=labs[i], color=cols[i], edgecolor='white', lw=0.3,
                  zorder=3, yerr=std[i], capsize=1.2,
                  error_kw=dict(lw=0.6, ecolor='#222', alpha=0.85, zorder=4))
    for j, (b, val, sd) in enumerate(zip(bars, acc[i], std[i])):
        if val > 25:
            ax.text(b.get_x()+b.get_width()/2, b.get_height()+sd+2.5, f'{val:.1f}',
                    ha='center', va='bottom', fontsize=4.5, rotation=0, color=cols[i])

ax.set_xticks(x); ax.set_xticklabels(['Leave-3000','Leave-500','Low→High','High→Low'], fontsize=7)
ax.set_ylabel('Accuracy (%)', fontsize=8); ax.set_ylim(0, 118)
ax.legend(ncol=6, loc='lower center', bbox_to_anchor=(0.5, 0.92), frameon=False,
          fontsize=5.5, handletextpad=0.3, columnspacing=0.8)
avg_6ch = acc[5].mean()
ax.axhline(y=avg_6ch, color=cols[-1], ls='--', lw=0.5, alpha=0.5)
ax.text(0.52, avg_6ch+2, f'6ch avg: {avg_6ch:.1f}%', fontsize=9, color=cols[-1], transform=ax.transData)
fig.tight_layout(pad=0.3)
save('fig2_ablation', fig)
print('fig2_ablation (multi-seed, mean+/-std n=5)  OK')
print('cell means:')
for i, c in enumerate(CONFS):
    print(f'  {c:<14}', ' '.join(f'{acc[i,j]:5.1f}+-{std[i,j]:4.1f}' for j in range(4)))
