"""
Fig: Grad-CAM + channel-resolved attribution (2x2 panels).

(a) Temporal Grad-CAM heatmap (50 outer-race samples, 128 bins).
(b) Per-class gradient x input attribution shares (radial / axial / current groups).
(c) Outer-race accuracy under channel/group occlusion (baseline 96.7%).
(d) Overall accuracy under channel/group occlusion (baseline 99.4%).

Data: data/gradcam_perchannel_results.json (experiment/run_gradcam_perchannel.py).
Run from the scripts/ directory.
"""
from fig_common import *

style()
d = load_json('gradcam_perchannel_results.json')
cam = np.array(d['mean_gradcam_temporal'])
pca = d['per_class_channel_attribution']
occ = d['occlusion']
base_all = d['meta']['baseline_overall_acc']
base_out = d['meta']['baseline_outer_acc']

fig, axes = plt.subplots(2, 2, figsize=(7.0, 4.6))

# ---- (a) temporal Grad-CAM ----
ax = axes[0, 0]
im = ax.imshow(cam[np.newaxis, :], aspect='auto', cmap='inferno', vmin=0, vmax=1)
ax.set_xlabel('Temporal bin (128 bins = 2048 samples)')
ax.set_yticks([])
ax.set_title('(a) Temporal Grad-CAM (outer race, n=50)', fontsize=8, loc='left')
plt.colorbar(im, ax=ax, label='Attribution', pad=0.02)

# ---- (b) per-class group attribution ----
ax = axes[0, 1]
groups = ['vib_radial', 'vib_axial', 'cur_all']
glabs = ['vib$_{X+Y}$ radial', 'vib$_Z$ axial', 'cur$_{ABC}$']
gcols = [C['blue'], C['cyan'], C['orange']]
y = np.arange(len(CLASSES))
left = np.zeros(len(CLASSES))
for g, gl, gc in zip(groups, glabs, gcols):
    vals = np.array([pca[c][g] for c in CLASSES])
    ax.barh(y, vals, left=left, color=gc, height=0.7, label=gl, edgecolor='white', lw=0.3)
    left += vals
ax.set_yticks(y); ax.set_yticklabels(LABS)
ax.invert_yaxis()
ax.set_xlabel('Attribution share (grad $\\times$ input)')
ax.set_xlim(0, 1.0)
ax.legend(fontsize=6, loc='lower right', framealpha=0.9)
ax.set_title('(b) Per-class channel-group attribution', fontsize=8, loc='left')

# ---- (c)(d) occlusion bars ----
tests = ['vib_X', 'vib_Y', 'vib_Z', 'cur_A', 'vib_all', 'cur_all']
tlabs = ['-vib$_X$', '-vib$_Y$', '-vib$_Z$', '-cur$_A$', '-vib$_{all}$', '-cur$_{all}$']
tcols = [C['blue'], C['cyan'], '#004C66', C['orange'], '#333333', '#B85C00']

for ax, key, base, title, legloc in [
    (axes[1, 0], 'outer_acc', base_out, '(c) Outer-race accuracy under occlusion', 'upper center'),
    (axes[1, 1], 'overall_acc', base_all, '(d) Overall accuracy under occlusion', 'upper right'),
]:
    vals = [occ[t][key] for t in tests]
    x = np.arange(len(tests))
    ax.bar(x, vals, color=tcols, width=0.65, edgecolor='white', lw=0.3)
    ax.axhline(base, color=C['red'], ls='--', lw=0.9,
               label=f'baseline {base:.1f}%')
    ax.legend(fontsize=6.5, loc=legloc, framealpha=0.95, edgecolor='none')
    ax.set_xticks(x); ax.set_xticklabels(tlabs, fontsize=6.5)
    ax.set_ylabel('Accuracy (%)')
    ax.set_ylim(0, 120)
    ax.set_title(title, fontsize=8, loc='left')
    for xi, v in zip(x, vals):
        ax.text(xi, v + 1.5, f'{v:.0f}', ha='center', fontsize=6, color='#333')

fig.tight_layout(pad=0.8)
save('fig10_gradcam', fig)
