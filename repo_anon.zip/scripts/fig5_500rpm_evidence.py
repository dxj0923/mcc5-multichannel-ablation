"""
Fig 5: Combined A+B — SNR-driven accuracy analysis.
2x2 layout:
  (a) Time-domain overlay — broken_bar vib_Z at 500 vs 3000 rpm
  (b) PSD comparison — Welch PSD of same signals
  (c) SNR bar chart — σ of vib_Z across 4 fault types at 500 vs 3000 rpm
  (d) Accuracy-vs-SNR scatter — per-channel config (from JSON)
"""
from fig_common import *; style(0.9)
try:
    from scipy import signal as sp_signal
    def welch_psd(v, fs, nperseg=256):
        return sp_signal.welch(v, fs, nperseg=nperseg)
except ImportError:  # scipy optional: fall back to matplotlib's PSD
    from matplotlib import mlab
    def welch_psd(v, fs, nperseg=256):
        P, f = mlab.psd(v, NFFT=nperseg, Fs=fs)
        return f, P
FS = 12800

# --- Load the exact plotted snippets (shipped with the repo) -----------------
# The raw steady-state CSVs are NOT distributed; the precise samples shown here
# were extracted from the dataset once by extract_fig_waveforms.py. We NEVER
# synthesize substitute data: if the JSON is missing, stop with instructions.
_sig_path = DATA / 'fig5_signals.json'
if not _sig_path.exists():
    raise SystemExit(
        f'FATAL: {_sig_path} not found. Either restore the shipped data/fig5_signals.json '
        'or re-extract from the raw dataset: set MCC5_ROOT and run '
        '`cd scripts && python extract_fig_waveforms.py`.')
_sig = load_json('fig5_signals.json')

def load_pair(fault):
    """Return (v_500_z, v_3000_z, raw_std_500, raw_std_3000) from shipped snippets."""
    out_z = []; out_std = []
    for speed in (500, 3000):
        rec = _sig['snippets'][fault][str(speed)]
        v = np.asarray(rec['vib_Z_raw'], dtype=float)
        raw_std = float(rec['raw_std'])
        assert abs(v.std() - raw_std) < 1e-4, f'snippet std mismatch for {fault} at {speed} rpm'
        v = (v - v.mean()) / (raw_std + 1e-8)
        out_z.append(v); out_std.append(raw_std)
    return out_z[0], out_z[1], out_std[0], out_std[1]

faults = [('health', 'Health'), ('broken_bar', 'Broken Bar'),
          ('bend', 'Bent Shaft'), ('winding', 'Winding')]

# Preload data
vib = {}; stds = {}; raw_stds = {}
for fn, fl in faults:
    v500, v3000, s500, s3000 = load_pair(fn)
    vib[(fn, 500)] = v500
    vib[(fn, 3000)] = v3000
    stds[(fn, 500)] = v500.std()
    stds[(fn, 3000)] = v3000.std()
    raw_stds[(fn, 500)] = s500
    raw_stds[(fn, 3000)] = s3000

fig, axes = plt.subplots(2, 2, figsize=(7.0, 5.5))

# === (a) Time-domain overlay (broken_bar) ===
ax = axes[0, 0]
fn_rep = 'broken_bar'
t = np.arange(1024) / FS * 1000
ax.plot(t, vib[(fn_rep, 500)], color=C['blue'], lw=0.6, alpha=0.8, label='500 rpm')
ax.plot(t, vib[(fn_rep, 3000)], color=C['red'],  lw=0.6, alpha=0.8, label='3000 rpm')
ax.set_ylim(-4, 4)
ax.set_xlabel('Time (ms)', fontsize=7)
ax.set_ylabel('Amplitude (z-score)', fontsize=7)
ax.set_title('(a) Time-domain overlay — broken bar vib$_Z$', fontsize=7.5, fontweight='bold')
ax.legend(fontsize=5.5, frameon=False)
ax.text(0.98, 0.05, f'raw σ$_{{500}}$={raw_stds[(fn_rep,500)]:.3f}  raw σ$_{{3000}}$={raw_stds[(fn_rep,3000)]:.3f} m/s$^2$',
        transform=ax.transAxes, fontsize=5.5, ha='right', va='bottom',
        bbox=dict(boxstyle='round,pad=0.15', facecolor='white', alpha=0.8, lw=0.3))

# === (b) PSD comparison (same fault) ===
ax = axes[0, 1]
f500, Pxx500 = welch_psd(vib[(fn_rep, 500)], FS)
f3000, Pxx3000 = welch_psd(vib[(fn_rep, 3000)], FS)
ax.semilogy(f500, Pxx500, color=C['blue'], lw=0.7, alpha=0.8, label='500 rpm')
ax.semilogy(f3000, Pxx3000, color=C['red'], lw=0.7, alpha=0.8, label='3000 rpm')
ax.set_xlim(0, 3000)
ax.set_ylim(5e-7, 2e-2)
ax.set_xlabel('Frequency (Hz)', fontsize=7)
ax.set_ylabel('PSD (1/Hz)', fontsize=7)
ax.set_title('(b) Welch PSD — broken bar vib$_Z$', fontsize=7.5, fontweight='bold')
ax.legend(fontsize=5.5, frameon=False)
ax.grid(True, alpha=0.15, lw=0.3)

# === (c) Raw amplitude vs speed (shipped per-speed sigma, exact-speed matching) ===
ax = axes[1, 0]
SPEEDS6 = [500, 1000, 1500, 2000, 2500, 3000]

def raw_sigma(fault, speed):
    """Mean raw vib_Z std over all single-fault segments at one exact speed
    (precomputed by extract_fig_waveforms.py; see data/fig5_signals.json)."""
    return _sig['panel_c_sigma'][fault][str(speed)]

for (fn, fl), col in zip(faults, [C['blue'], C['red'], C['green'], C['orange']]):
    sigs = [raw_sigma(fn, s) for s in SPEEDS6]
    ax.plot(SPEEDS6, sigs, 'o-', color=col, lw=0.9, ms=3, label=fl)
ax.set_yscale('log')
ax.set_xticks(SPEEDS6)
ax.set_xlabel('Speed (rpm)', fontsize=7)
ax.set_ylabel('Raw vib$_Z$ $\\sigma$ (m/s$^2$)', fontsize=7)
ax.set_title('(c) Raw vibration amplitude vs. speed', fontsize=7.5, fontweight='bold')
ax.legend(fontsize=5.5, frameon=False)
ax.grid(True, alpha=0.15, lw=0.3, which='both')

# === (d) Accuracy vs raw amplitude (all values from JSON + measured σ) ===
ax = axes[1, 1]
# Multi-seed means (n=5) replace single-run ablation_results.json (2026-07-30)
_msf = load_json('multi_seed_results_full.json')
def _ms_acc(scen, cfg):
    vals = [e['best_acc'] for e in _msf if e['scenario'] == scen and e['config'] == cfg]
    return float(np.mean(vals))
abl = {k: {'best_acc': v / 100} for k, v in {
    'leave_3000_vib_XYZ': _ms_acc('leave_3000', 'vib_XYZ'),
    'leave_500_vib_XYZ': _ms_acc('leave_500', 'vib_XYZ'),
    'leave_3000_vibcur_6ch': _ms_acc('leave_3000', 'vibcur_6ch'),
    'leave_500_vibcur_6ch': _ms_acc('leave_500', 'vibcur_6ch'),
}.items()}
s3000 = np.mean([raw_stds[(fn, 3000)] for fn, _ in faults])
s500 = np.mean([raw_stds[(fn, 500)] for fn, _ in faults])

series = [
    ('vib$_{XYZ}$', C['blue'], 'o',
     [(s3000, abl['leave_3000_vib_XYZ']['best_acc'] * 100),
      (s500,  abl['leave_500_vib_XYZ']['best_acc'] * 100)]),
    ('vibcur$_{6ch}$', C['green'], 's',
     [(s3000, abl['leave_3000_vibcur_6ch']['best_acc'] * 100),
      (s500,  abl['leave_500_vibcur_6ch']['best_acc'] * 100)]),
]
for name, col, mk, pts in series:
    xs = [p[0] for p in pts]; ys = [p[1] for p in pts]
    ax.plot(xs, ys, color=col, lw=0.8, ls='--', alpha=0.5, zorder=2)
    for (sx, sy), lab in zip(pts, ['3000 rpm', '500 rpm']):
        ax.scatter(sx, sy, c=col, s=60, marker=mk, zorder=3, edgecolors='white', linewidth=0.5)
        if sx == s500:
            _ha, _va, _off = 'left', 'center', (10, 11)
        elif '6ch' in name:
            _ha, _va, _off = 'right', 'bottom', (-10, 9)
        else:
            _ha, _va, _off = 'right', 'top', (-10, -12)
        ax.annotate(f'{name}, {lab}\n{sy:.1f}%', (sx, sy), fontsize=5.5,
                    ha=_ha, va=_va, textcoords='offset points', xytext=_off)
ax.set_xscale('log')
ax.set_xlabel('Mean raw vib$_Z$ $\\sigma$ (m/s$^2$, log scale)', fontsize=7)
ax.set_ylabel('Target accuracy (%)', fontsize=7)
ax.set_title('(d) Accuracy vs raw vibration amplitude', fontsize=7.5, fontweight='bold')
ax.set_ylim(40, 108)
ax.grid(True, alpha=0.15, lw=0.3, which='both')

fig.tight_layout(pad=0.5)
save('fig5_500rpm_evidence', fig)
