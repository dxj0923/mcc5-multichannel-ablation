"""Figure: Cross-load robustness (P3-6)."""
import sys, json, numpy as np
sys.path.insert(0, '.')
from fig_common import *  # run from the scripts/ directory

style(0.95)

data = load_json('cross_load_results.json')
classes = list(data['20Nm']['per_class'].keys())
v20 = [data['20Nm']['per_class'][c] for c in classes]
v40 = [data['40Nm']['per_class'][c] for c in classes]
o20, o40 = data['20Nm']['overall'], data['40Nm']['overall']

fig, ax = plt.subplots(figsize=(6.5, 3.2))
x = np.arange(len(classes))
w = 0.32

ax.bar(x - w/2, v20, w, label=f'20Nm ({o20}%)', color=C['blue'], ec='white', lw=0.4)
bars = ax.bar(x + w/2, v40, w, label=f'40Nm ({o40}%)', color=C['green'], ec='white', lw=0.4)

# Highlight below-99 bars with a red edge instead of recoloring (keeps legend consistent)
for bar, v in zip(bars, v40):
    if v < 99:
        bar.set_edgecolor(C['red'])
        bar.set_linewidth(1.2)
        ax.annotate(f'{v:.1f}%', (bar.get_x()+bar.get_width(), bar.get_height()),
                    textcoords='offset points', xytext=(5, 5), ha='left', fontsize=7,
                    fontweight='bold', color=C['red'])

# Explicit legend proxies so swatch colors always match the bars
from matplotlib.patches import Patch
ax.legend(handles=[Patch(facecolor=C['blue'], label=f'20Nm ({o20}%)'),
                   Patch(facecolor=C['green'], label=f'40Nm ({o40}%)')],
          fontsize=7, loc='lower right')

ax.axhline(y=o20, color=C['blue'], ls='--', lw=0.6, alpha=0.3)
ax.axhline(y=o40, color=C['green'], ls='--', lw=0.6, alpha=0.3)
ax.set_ylabel('Accuracy (%)')
ax.set_xticks(x)
ax.set_xticklabels(classes, rotation=45, ha='right', fontsize=7)
ax.set_ylim(94, 101)

save('fig7_cross_load')
