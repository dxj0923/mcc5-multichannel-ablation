"""
Fig 9: Practical decision framework (rebuilt in matplotlib).

Top: per-class modality preference taxonomy (3 groups, multi-seed means from Table 3).
Bottom: three-tier deployment strategy (numbers from per_class_optimal_multiseed.json, n=5).
Tier 2 updated (2026-07-30): vib_Z specialist for outer race (99.9+/-0.1%, most stable config
for this class), replacing the former dual-branch fallback.
"""
from fig_common import *; style()
import json

d = load_json('per_class_optimal_multiseed.json')
oracle = d['oracle_acc'] * 100      # 99.9
vibcur = d['vibcur_acc'] * 100      # 99.2

fig, ax = plt.subplots(figsize=(7.0, 3.6))
ax.set_xlim(0, 10); ax.set_ylim(0, 10); ax.axis('off'); ax.grid(False)

# ---------- Top: taxonomy ----------
ax.text(5, 9.55, 'Per-Class Modality Preference (leave-3000)',
        ha='center', fontsize=8, fontweight='bold', color='#333')

box(ax, 1.9, 7.6, 3.4, 2.5,
    'Vibration-Preferred (5)\n\nhealth, inner race, ball,\nbroken bar, bent shaft\n\nvib$_{XYZ}$: 90–100%',
    C['blue'], fs=5.8)
box(ax, 5.0, 7.6, 2.6, 2.5,
    'Multi-Modal (3)\n\nouter race, winding,\ndynamic eccentricity\n\nfusion: 96–100%',
    C['green'], fs=5.8)
box(ax, 8.1, 7.6, 3.4, 2.5,
    'Current-Preferred (2)\n\nstatic eccentricity,\nvoltage imbalance\n\ncur$_{ABC}$: 97–100%',
    C['orange'], fs=5.8)

# ---------- Bottom: tiers ----------
ax.text(6.5, 5.6, 'Deployment Tiers', ha='center', fontsize=8, fontweight='bold', color='#333')

box(ax, 1.9, 3.4, 3.4, 2.6,
    f'Tier 1: Default\n\nvibcur$_{{6ch}}$ early fusion\n{vibcur:.1f}% macro avg\n1 model, 1 pass',
    '#333333', fs=5.8)
box(ax, 5.0, 3.4, 2.6, 2.6,
    'Tier 2: Specialist\n\n+ vib$_Z$ for\nouter race (99.9%)\n2 models, 2 passes',
    C['purple'], fs=5.8)
box(ax, 8.1, 3.4, 3.4, 2.6,
    f'Tier 3: Oracle (bound)\n\nper-class best config\n{oracle:.1f}% upper bound\n5 experts, test-set sel.',
    C['red'], fs=5.8)

arr(ax, 1.9, 6.3, 1.9, 4.75, c='#555', lw=1.0)
arr(ax, 5.0, 6.3, 5.0, 4.75, c='#555', lw=1.0)
arr(ax, 8.1, 6.3, 8.1, 4.75, c='#555', lw=1.0)

fig.tight_layout(pad=0.3)
save('fig9_decision_tree', fig)
