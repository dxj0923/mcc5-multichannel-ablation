"""
Pareto efficiency-accuracy figure.

All seven configurations are shown. Marker size encodes input channel count.
Accuracy source (2026-10-12): multi-seed means from multi_seed_results_full.json
  (leave-3000, n=5) for ALL configurations; the legacy multi_seed_summary.json
  fallback was removed.
"""
import sys, json, numpy as np
sys.path.insert(0, '.')
from fig_common import *  # run from the scripts/ directory

style(0.95)

pareto = load_json('pareto_analysis.json')
# Multi-seed means (n=5) for all configurations (raw file now covers every cell)
_msf = load_json('multi_seed_results_full.json')
_ms_acc = {}
for _e in _msf:
    if _e['scenario'] == 'leave_3000':
        _ms_acc.setdefault(_e['config'], []).append(_e['best_acc'])

config_map = {
    'vib_Z': 'vib$_Z$ (1ch)', 'vib_XY': 'vib$_{XY}$ (2ch)', 'vib_XYZ': 'vib$_{XYZ}$ (3ch)',
    'cur_ABC': 'cur$_{ABC}$ (3ch)', 'vib_XYZ_curA': 'vib$_{XYZ}$+cur$_A$ (4ch)',
    'vibcur_6ch': 'vibcur$_{6ch}$ (6ch)', 'dual_branch': 'Dual-branch (6ch)',
}
order = ['vib_Z', 'vib_XY', 'vib_XYZ', 'cur_ABC', 'vib_XYZ_curA', 'vibcur_6ch', 'dual_branch']
colors = dict(zip(order, [C['blue'], C['cyan'], C['green'], C['orange'],
                          C['purple'], C['red'], C['black']]))

def accuracy(cfg):
    return float(np.mean(_ms_acc[cfg]))

short = {'vib_Z': 'vib$_Z$\n1ch', 'vib_XY': 'vib$_{XY}$\n2ch', 'vib_XYZ': 'vib$_{XYZ}$\n3ch',
         'cur_ABC': 'cur$_{ABC}$\n3ch', 'vib_XYZ_curA': '+cur$_A$\n4ch',
         'vibcur_6ch': '6ch\nfusion', 'dual_branch': 'dual-\nbranch'}
lat = {p['config']: p['latency_ms'] for p in pareto if p['config'] in config_map}
acc = {c: accuracy(c) for c in order}
x = np.arange(len(order))

fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.0))

# (a) accuracy vs configuration
ax = axes[0]
for xi, c in zip(x, order):
    mk = 's' if c == 'dual_branch' else 'o'
    ax.scatter(xi, acc[c], s=55, color=colors[c], marker=mk, zorder=5,
               edgecolors='white', linewidths=0.5)
    ax.annotate(f'{acc[c]:.1f}', (xi, acc[c]), textcoords='offset points',
                xytext=(0, 8), ha='center', fontsize=6.5, fontweight='bold',
                color=colors[c])
ax.set_xticks(x); ax.set_xticklabels([short[c] for c in order], fontsize=6)
ax.set_ylabel('Leave-3000 Accuracy (%)')
ax.set_ylim(84, 102)
ax.set_title('(a) Accuracy vs. configuration', fontsize=8, loc='left')
ax.grid(True, axis='y', alpha=0.15, lw=0.3)

# (b) latency vs configuration (bars from zero: flatness is the message)
ax = axes[1]
ax.bar(x, [lat[c] for c in order], width=0.6,
       color=[colors[c] for c in order], edgecolor='white', lw=0.4)
for xi, c in zip(x, order):
    ax.annotate(f'{lat[c]:.2f}', (xi, lat[c]), textcoords='offset points',
                xytext=(0, 3), ha='center', fontsize=6, color='#333')
ax.set_xticks(x); ax.set_xticklabels([short[c] for c in order], fontsize=6)
ax.set_ylabel('Inference Latency (ms)')
ax.set_ylim(0, 2.2)
ax.set_title('(b) Latency vs. configuration', fontsize=8, loc='left')
ax.grid(True, axis='y', alpha=0.15, lw=0.3)

fig.tight_layout(pad=0.6)

save('fig11_pareto')
