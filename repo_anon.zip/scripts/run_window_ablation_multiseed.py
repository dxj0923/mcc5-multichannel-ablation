"""
Window Length Ablation with multi-seed statistics (leave-500, 6ch early fusion).
Same protocol as scripts/run_window_ablation.py (EPOCHS=25, per-window Z-score,
non-overlapping windows) but with seeds [42, 123, 456] -> mean +/- std.

RESUMABLE: results are appended to data/window_ablation_multiseed_results.json
after every run; re-running skips completed (window_size, seed) pairs.
Phase-1 CSV cache (data/preprocessed_csv) is reused if present.

Run from the REPO ROOT of the D-drive copy:
    cd <repo_root>
    python scripts\run_window_ablation_multiseed.py

Estimated runtime: ~2-3 h on GPU (9 runs).
"""
import os
import sys, os, time, json, re, hashlib, numpy as np, pandas as pd
from pathlib import Path

# ---- Config ----
STEADY_CSV = Path(os.environ.get('MCC5_ROOT', './raw_data')) / 'steady_csv'
CACHE_DIR = Path('data/preprocessed_csv')
WINDOW_SIZES = [2048, 4096, 8192]  # samples
SEEDS = [42, 123, 456]
SR = 12800  # Hz
SOURCE_DOMAINS = [1000, 1500, 2000, 2500, 3000]  # leave-500
TARGET_DOMAIN = [500]
EPOCHS = 25
OUT = Path('data/window_ablation_multiseed_results.json')

# ---- Fault mapping (identical to run_window_ablation.py) ----
FAULT_TO_ORIGINAL = {
    'health': 0,
    'bearing_inner_H': 1, 'bearing_inner_L': 2,
    'bearing_outer_H': 3, 'bearing_outer_L': 4,
    'bearing_ball_H': 5, 'bearing_ball_L': 5,
    'winding_H': 6, 'winding_L': 7,
    'static_eccentricity_H': 8, 'static_eccentricity_L': 9,
    'dynamic_eccentricity': 10,
    'broken_bar': 11,
    'voltage_unbalance_L': 12,
    'bend': 13,
}
LABEL_MERGE = {0:0, 1:1, 2:1, 3:2, 4:2, 5:3, 6:4, 7:4, 8:5, 9:5, 10:6, 11:7, 12:8, 13:9}

def parse_fault(fstem):
    parts = fstem.split('_')
    cond_idx = None
    for i, p in enumerate(parts):
        if p in ('speed', 'torque') and i + 1 < len(parts) and parts[i + 1] == 'circulation':
            cond_idx = i; break
    if cond_idx is None: return None, None
    fault_str = '_'.join(parts[:cond_idx])
    if '_and_' in fault_str: return None, None
    orig = FAULT_TO_ORIGINAL.get(fault_str)
    if orig is None: return None, None
    return LABEL_MERGE.get(orig), fault_str

def parse_torque(fstem):
    for p in fstem.split('_'):
        if p.endswith('Nm'):
            try: return int(p.replace('Nm', ''))
            except: pass
    return None

def parse_domain(fstem):
    m = re.search(r'_D_speed_(\d+)_rpm', fstem)
    if m: return int(m.group(1))
    return None

def file_hash(fpath):
    return hashlib.md5(str(fpath).encode()).hexdigest()[:12]

# ============ Phase 1: Build Cache (reused if present) ============
CACHE_DIR.mkdir(parents=True, exist_ok=True)
meta_path = CACHE_DIR / 'meta.json'

cache_meta = None
if meta_path.exists():
    print('Loading preprocessed cache...', flush=True)
    with open(meta_path) as f:
        cache_meta = json.load(f)
    if not all((CACHE_DIR / e['npy']).exists() for e in cache_meta):
        print('  Cache incomplete, rebuilding...', flush=True)
        cache_meta = None

if cache_meta is None:
    print('Phase 1: Preprocessing all CSV files...', flush=True)
    cache_meta = []
    csv_files = sorted(STEADY_CSV.glob('*.csv'))
    t_start = time.time()
    for idx, f in enumerate(csv_files):
        domain = parse_domain(f.stem)
        torque = parse_torque(f.stem)
        fault_label, _ = parse_fault(f.stem)
        if None in (domain, torque, fault_label):
            continue
        try:
            df = pd.read_csv(f, header=None, skiprows=1, usecols=[3, 4, 5, 6, 7, 8])
        except Exception as e:
            print(f'  WARN: failed to read {f.name}: {e}', flush=True)
            continue
        arr = df.values.astype(np.float32)
        npy_name = f'{domain}_{torque}Nm_{file_hash(f)}.npy'
        np.save(str(CACHE_DIR / npy_name), arr)
        cache_meta.append({'npy': npy_name, 'domain': domain, 'torque': torque,
                           'fault_label': fault_label, 'samples': len(arr), 'file': f.name})
        if (idx + 1) % 50 == 0 or idx == len(csv_files) - 1:
            print(f'  [{idx+1}/{len(csv_files)}] {time.time()-t_start:.0f}s', flush=True)
    with open(meta_path, 'w') as f:
        json.dump(cache_meta, f, indent=2)
    print(f'  Done: {len(cache_meta)} files cached', flush=True)

# ============ Phase 2: Multi-seed training ============
import torch, torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'\nDevice: {DEVICE}', flush=True)

def cache_to_windows(domain_list, window_size):
    """Load cached raw npy arrays, window (non-overlapping), Z-score per window."""
    X_list, y_list = [], []
    entries = [e for e in cache_meta if e['domain'] in domain_list]
    for e in entries:
        arr = np.load(str(CACHE_DIR / e['npy']))
        if len(arr) < window_size: continue
        n_win = len(arr) // window_size
        trimmed = arr[:n_win * window_size].reshape(-1, window_size, 6).transpose(0, 2, 1)
        m = trimmed.mean(axis=2, keepdims=True)
        s = trimmed.std(axis=2, keepdims=True) + 1e-8
        trimmed = (trimmed - m) / s
        X_list.append(trimmed)
        y_list.append(np.full(n_win, e['fault_label']))
    if not X_list: return np.zeros((0, 6, window_size)), np.zeros(0, dtype=np.int64)
    return np.concatenate(X_list), np.concatenate(y_list)

class TinyCNN(nn.Module):
    def __init__(self, in_c=6, n_cls=10):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_c, 32, 15, padding=7, bias=False),
            nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 11, padding=5, bias=False),
            nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 9, padding=4, bias=False),
            nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128, 256, 7, padding=3, bias=False),
            nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(256, 256, 5, padding=2, bias=False),
            nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(256, 128), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, n_cls),
        )
    def forward(self, x):
        return self.net(x)

# resume support
results = json.load(open(OUT)) if OUT.exists() else []
if results:
    print(f'Resuming: {len(results)} runs already completed', flush=True)
finished = {(r['window_size'], r['seed']) for r in results}

def save():
    with open(OUT, 'w') as f:
        json.dump(results, f, indent=2)

for ws in WINDOW_SIZES:
    ws_ms = ws * 1000 / SR
    print(f'\n=== Window: {ws} samples ({ws_ms:.0f}ms) ===', flush=True)
    X_src, y_src = cache_to_windows(SOURCE_DOMAINS, ws)
    X_tgt, y_tgt = cache_to_windows(TARGET_DOMAIN, ws)
    print(f'  Source: {X_src.shape}, Target: {X_tgt.shape}', flush=True)
    if len(X_src) == 0 or len(X_tgt) == 0:
        print('  SKIP: no data', flush=True)
        continue

    for seed in SEEDS:
        if (ws, seed) in finished:
            print(f'  seed={seed}: SKIP (done)', flush=True)
            continue
        t0 = time.time()
        torch.manual_seed(seed); np.random.seed(seed)
        dl_src = DataLoader(TensorDataset(torch.from_numpy(X_src).float(), torch.from_numpy(y_src).long()),
                            256, shuffle=True, drop_last=True, pin_memory=True)
        dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tgt).float(), torch.from_numpy(y_tgt).long()),
                            512, shuffle=False, pin_memory=True)
        model = TinyCNN(in_c=6, n_cls=10).to(DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        best = 0.0
        for ep in range(EPOCHS):
            model.train()
            for xb, yb in dl_src:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
            sched.step()
            model.eval(); correct = 0
            with torch.no_grad():
                for xb, yb in dl_tgt:
                    p = model(xb.to(DEVICE)).argmax(1)
                    correct += p.eq(yb.to(DEVICE)).sum().item()
            acc = correct / len(dl_tgt.dataset)
            if acc > best: best = acc
            if (ep + 1) % 5 == 0:
                print(f'  seed={seed} epoch {ep+1}/{EPOCHS} best={best*100:.2f}%', flush=True)
        elapsed = time.time() - t0
        results.append({'window_size': ws, 'window_ms': round(ws_ms, 1),
                        'best_acc': round(float(best) * 100, 2),
                        'seed': seed, 'elapsed_s': round(elapsed, 1)})
        print(f'  seed={seed}: best={best*100:.2f}% ({elapsed:.0f}s)', flush=True)
        save()

# ---- summary: mean +/- std per window ----
print('\n=== Window ablation summary (leave-500, 6ch, n=3 seeds) ===', flush=True)
summary = {}
for ws in WINDOW_SIZES:
    accs = [r['best_acc'] for r in results if r['window_size'] == ws]
    if accs:
        summary[str(ws)] = {
            'window_ms': round(ws * 1000 / SR, 1),
            'n_seeds': len(accs),
            'mean': round(float(np.mean(accs)), 2),
            'std': round(float(np.std(accs, ddof=1)), 2) if len(accs) > 1 else 0.0,
            'values': accs,
        }
        print(f"  {ws} ({ws*1000/SR:.0f}ms): {np.mean(accs):.2f} +/- {np.std(accs, ddof=1) if len(accs)>1 else 0:.2f}  {accs}", flush=True)
with open('data/window_ablation_multiseed_summary.json', 'w') as f:
    json.dump(summary, f, indent=2)
print('\nSaved: data/window_ablation_multiseed_results.json, data/window_ablation_multiseed_summary.json', flush=True)
