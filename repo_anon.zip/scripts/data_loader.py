"""
Data loading pipeline for MCC5-THU S1 Full dataset.
Supports:
- Sliding window extraction from CSV signals
- Multi-modal (vibration + current)
- Domain/label-aware batching
- Pre-computed STFT features
"""
import numpy as np
import pandas as pd
from pathlib import Path
from torch.utils.data import Dataset, DataLoader
import os, re, warnings
warnings.filterwarnings('ignore')

DATA_DIR = Path(os.environ.get('MCC5_ROOT', './raw_data'))
STEADY_CSV = DATA_DIR / 'steady_csv'
CACHE_STFT = DATA_DIR / 'cache_stft'

# Fault label mapping
LABEL_MAP = {
    'health': 0,
    'bearing_inner_l': 1, 'bearing_inner_h': 2,
    'bearing_outer_l': 3, 'bearing_outer_h': 4,
    'bearing_ball': 5,
    'winding_l': 10, 'winding_h': 11,
    'static_eccentricity_l': 12, 'static_eccentricity_h': 13,
    'dynamic_eccentricity': 14,
    'broken_bar': 15,
    'voltage_unbalance': 16,
    'bend': 17,
}
LABEL_NAMES = {0:'health', 1:'inner_L', 2:'inner_H', 3:'outer_L', 4:'outer_H',
               5:'ball', 10:'winding_L', 11:'winding_H', 12:'static_L',
               13:'static_H', 14:'dynamic', 15:'broken_bar', 16:'voltage_ub', 17:'bend'}

# Map original labels to contiguous 0-13
ORIG_TO_CONTIGUOUS = {0:0, 1:1, 2:2, 3:3, 4:4, 5:5, 10:6, 11:7, 12:8, 13:9, 14:10, 15:11, 16:12, 17:13}
CONTIGUOUS_TO_ORIG = {v:k for k,v in ORIG_TO_CONTIGUOUS.items()}
NUM_CLASSES = 14

def parse_filename(fname):
    """Parse filename → metadata dict."""
    name = fname.lower()
    stem = Path(fname).stem.lower()
    
    label = -1
    label_name = 'unknown'
    for key, val in sorted(LABEL_MAP.items(), key=lambda x: -len(x[0])):
        if key in stem:
            label = val
            label_name = key
            break
    
    is_composite = 'and' in stem
    m = re.search(r'd_speed_(\d+)', name)
    domain = int(m.group(1)) if m else -1
    m = re.search(r'rpm([\d.]+)_npulses', name)
    exact_rpm = float(m.group(1)) if m else -1.0
    m = re.search(r'npulses(\d+)', name)
    npulses = int(m.group(1)) if m else -1
    m = re.search(r'(\d+)nm', name)
    torque = int(m.group(1)) if m else -1
    
    return {
        'filename': fname,
        'label': label, 'label_name': label_name,
        'is_composite': is_composite,
        'domain': domain, 'exact_rpm': exact_rpm,
        'npulses': npulses, 'torque': torque,
    }


def sliding_window_zscore(signal, window_size=2048, step_size=512):
    """Sliding window with z-score normalization."""
    samples = []
    for start in range(0, len(signal) - window_size + 1, step_size):
        sample = signal[start:start + window_size].astype(np.float32)
        sample = (sample - sample.mean()) / (sample.std() + 1e-8)
        samples.append(sample)
    return np.stack(samples) if samples else np.array([], dtype=np.float32)


class FaultDataset(Dataset):
    """
    Torch Dataset for loading signal windows from CSV files.
    Supports filtering by domain, label, torque for cross-domain experiments.
    """
    def __init__(self, domain=None, label=None, torque=None,
                 single_label_only=True, window_size=2048, step_size=512,
                 signal_col=5, use_stft=False, domains=None, labels=None):
        """
        Args:
            domain: int or list, filter by speed domain
            label: int or list, filter by fault label
            torque: int, filter by torque (20 or 40)
            single_label_only: bool, exclude composite fault files
            window_size: int, sliding window size
            step_size: int, sliding window stride
            signal_col: int, column index for signal (5=vib_Z, 6=cur_A)
            use_stft: bool, use pre-computed STFT features instead of raw signals
            domains: list of domains to include (alternative to domain)
            labels: list of labels to include (alternative to label)
        """
        self.window_size = window_size
        self.step_size = step_size
        self.signal_col = signal_col
        self.use_stft = use_stft
        
        # Determine directory
        if use_stft:
            self.data_dir = CACHE_STFT
        else:
            self.data_dir = STEADY_CSV
        
        # Parse all files
        all_files = sorted(self.data_dir.glob('*.csv' if not use_stft else '*.npy'))
        self.metadata = []
        for f in all_files:
            meta = parse_filename(f.name)
            
            # Filter
            if single_label_only and meta['is_composite']:
                continue
            
            if domain is not None:
                d_list = [domain] if isinstance(domain, int) else domain
                if meta['domain'] not in d_list:
                    continue
            if domains is not None:
                if meta['domain'] not in domains:
                    continue
                    
            if label is not None:
                l_list = [label] if isinstance(label, int) else label
                if meta['label'] not in l_list:
                    continue
            if labels is not None:
                if meta['label'] not in labels:
                    continue
                    
            if torque is not None:
                if meta['torque'] != torque:
                    continue
            
            self.metadata.append({
                'path': str(f),
                'domain': meta['domain'],
                'label': meta['label'],
                'torque': meta['torque'],
                'exact_rpm': meta['exact_rpm'],
                'npulses': meta['npulses'],
                'label_name': meta['label_name'],
            })
        
        # Pre-load and window all data
        self.samples = []
        self.labels = []
        self.domains = []
        self.torques = []
        self.file_indices = []
        
        for idx, meta in enumerate(self.metadata):
            if use_stft:
                data = np.load(meta['path'], allow_pickle=True)
                # STFT shape: (n_windows, 2, 128, 16) — already windowed
                n_windows = data.shape[0]
                for w in range(n_windows):
                    self.samples.append(data[w])
                    self.labels.append(ORIG_TO_CONTIGUOUS.get(meta['label'], meta['label']))
                    self.domains.append(meta['domain'])
                    self.torques.append(meta['torque'])
                    self.file_indices.append(idx)
            else:
                df = pd.read_csv(meta['path'], header=None)
                signal = df.iloc[:, self.signal_col].values.astype(np.float32)
                windows = sliding_window_zscore(signal, window_size, step_size)
                if len(windows) == 0:
                    continue
                for w in range(len(windows)):
                    self.samples.append(windows[w])
                    self.labels.append(ORIG_TO_CONTIGUOUS.get(meta['label'], meta['label']))
                    self.domains.append(meta['domain'])
                    self.torques.append(meta['torque'])
                    self.file_indices.append(idx)
        
        self.samples = np.array(self.samples)
        self.labels = np.array(self.labels, dtype=np.int64)
        self.domains = np.array(self.domains, dtype=np.int64)
        
    def __len__(self):
        return len(self.labels)
    
    def __getitem__(self, idx):
        x = self.samples[idx]
        if self.use_stft:
            x = x.astype(np.float32)  # already windowed
        else:
            x = x.reshape(1, -1)  # add channel dim
        return {
            'x': x,
            'label': self.labels[idx],
            'domain': self.domains[idx],
        }


def create_dataloaders(source_domains, target_domains, batch_size=64,
                       window_size=2048, step_size=512, signal_col=5,
                       use_stft=False, torque=None, num_workers=0):
    """
    Create source and target dataloaders for domain generalization experiments.
    """
    source_dataset = FaultDataset(
        domains=source_domains, torque=torque,
        window_size=window_size, step_size=step_size,
        signal_col=signal_col, use_stft=use_stft
    )
    target_dataset = FaultDataset(
        domains=target_domains, torque=torque,
        window_size=window_size, step_size=step_size,
        signal_col=signal_col, use_stft=use_stft
    )
    
    source_loader = DataLoader(source_dataset, batch_size=batch_size,
                               shuffle=True, num_workers=num_workers,
                               drop_last=True)
    target_loader = DataLoader(target_dataset, batch_size=batch_size,
                               shuffle=False, num_workers=num_workers)
    
    return source_loader, target_loader, source_dataset, target_dataset


def get_domain_label_distribution(domains=None, single_label_only=True, torque=None):
    """Get class distribution for given domains (for stratified sampling)."""
    ds = FaultDataset(domains=domains, single_label_only=single_label_only, torque=torque)
    from collections import Counter
    return Counter(ds.labels.tolist())


if __name__ == '__main__':
    # Quick test
    ds = FaultDataset(domain=1000, single_label_only=True, signal_col=5)
    print(f"Dataset: {len(ds)} samples, {len(set(ds.labels))} classes")
    print(f"  Class dist: {dict(zip(*np.unique(ds.labels, return_counts=True)))}")
    
    loader = DataLoader(ds, batch_size=32, shuffle=True)
    batch = next(iter(loader))
    print(f"  Batch x shape: {batch['x'].shape}")
    print(f"  Batch labels: {batch['label'].shape}")
    print(f"  Batch domains: {batch['domain'].shape}")
