"""
Fig 3: Per-class heatmap across 5 configurations (leave-3000).

Data source: data/per_class_optimal_multiseed.json (multi-seed means, n=5; same source as Table 5).

== ADJUSTABLE SETTINGS ==
  - figsize=(7.0, 3.2): overall figure size
  - cmap='RdYlGn': color map for heatmap
  - vmin=0, vmax=100: heatmap color scale range
"""
from fig_common import *; style()
import json

d = load_json('per_class_optimal_multiseed.json')
pc = d['per_class']

cfgs = [('vib$_Z$',       'vib_Z',       C['blue']),
        ('vib$_{XYZ}$',   'vib_XYZ',     C['red']),
        ('cur$_{ABC}$',   'cur_ABC',     C['orange']),
        ('vibcur$_{6ch}$','vibcur_6ch',  C['green']),
        ('Dual',          'dual_branch', C['purple'])]

mat = np.array([[pc[key][c] * 100 for c in CLASSES] for _, key, _ in cfgs])

fig = plt.figure(figsize=(7.0, 3.2))

# --- Heatmap panel ---
ah = fig.add_axes([0.055, 0.13, 0.50, 0.78])
im = ah.imshow(mat, aspect='auto', cmap='RdYlGn', vmin=0, vmax=100)
ah.set_yticks(range(5)); ah.set_yticklabels([l for l, _, _ in cfgs], fontsize=6.5)
ah.set_xticks(range(10)); ah.set_xticklabels(LABS, rotation=35, ha='right', fontsize=6)
for i in range(5):
    for j in range(10):
        val = mat[i, j]
        c = 'white' if val < 40 else 'black'
        ah.text(j, i, f'{val:.0f}', ha='center', va='center', fontsize=5, color=c, fontweight='bold')
ah.grid(False)

cax = fig.add_axes([0.565, 0.13, 0.014, 0.78])
cb = fig.colorbar(im, cax=cax, ticks=[0, 25, 50, 75, 100])
cb.ax.tick_params(labelsize=5.5)
cb.ax.set_ylabel('Accuracy (%)', fontsize=6.5)

# --- Right panel: number of classes within 0.5 pp of the per-class best ---
ad = fig.add_axes([0.70, 0.13, 0.27, 0.78])
best = mat.max(axis=0)
counts = [(mat[i] >= best - 0.5).sum() for i in range(5)]
bars = ad.barh(range(5), counts, color=[c for _, _, c in cfgs], height=0.6,
               edgecolor='white', lw=0.3)
ad.set_yticks(range(5)); ad.set_yticklabels([l for l, _, _ in cfgs], fontsize=6.5)
ad.set_xlabel('Classes within 0.5 pp of best', fontsize=6.5)
ad.set_xlim(0, 11)
ad.tick_params(labelsize=5.5)
ad.grid(axis='x', alpha=0.2)
for b, cnt in zip(bars, counts):
    ad.text(cnt + 0.15, b.get_y() + b.get_height() / 2, f'{cnt}',
            ha='left', va='center', fontsize=6.5, fontweight='bold')

save('fig3_heatmap', fig)
