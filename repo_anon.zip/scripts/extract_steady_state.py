# -*- coding: utf-8 -*-
"""
Steady-state segment extraction from raw MCC5-THU speed-circulation recordings.

Re-implementation of the pipeline documented in DATASET_GUIDE.md (v5.0 Full):
  1. Detect keyphase pulses: rising-edge crossings of 1.0 V.
  2. Instantaneous RPM per inter-pulse interval: RPM = 60 * fs / interval_samples.
  3. Map intervals to speed domains: target +/- 10% (500/1000/1500/2000/2500/3000).
  4. Maximal runs of consecutive intervals in the same domain -> candidate segments
     (candidate needs >= MIN_PULSES pulses; final keep requires n_pulses >= KEEP_PULSES).
  5. Exact RPM per segment: linear regression polyfit(t_pulses, arange(n), 1) * 60.
  6. Segment data = raw rows [first_pulse .. last_pulse] (inclusive, all 9 columns).

Usage:
  python extract_steady_state.py --raw-dir <raw_csv_dir> --out-dir <steady_csv_dir> [--file NAME]
  python extract_steady_state.py --verify --raw-dir <raw> --steady-dir <steady_csv> [--file NAME]
"""
import os
import argparse, os, sys, time
import numpy as np
import pandas as pd
from pathlib import Path

FS = 12800
KP_THRESHOLD = 1.0
DOMAINS = [500, 1000, 1500, 2000, 2500, 3000]
BAND = 0.10
MIN_PULSES = 20      # candidate segment minimum (guide: min_pulses)
KEEP_PULSES = 100    # final keep threshold (guide: n_pulses >= 100)


def detect_pulses(keyphase: np.ndarray) -> np.ndarray:
    """Rising-edge crossings of KP_THRESHOLD -> sample indices (first sample >= thr)."""
    return np.where((keyphase[:-1] < KP_THRESHOLD) & (keyphase[1:] >= KP_THRESHOLD))[0] + 1


def extract_segments(df: pd.DataFrame):
    """Return list of dicts: domain, start, end (inclusive row idx), n_pulses, rpm_exact."""
    kp = df.iloc[:, 1].values
    pulses = detect_pulses(kp)
    if len(pulses) < 3:
        return []
    intervals = np.diff(pulses)
    rpm = 60.0 * FS / intervals                       # per-interval rpm, len = n_pulses-1
    in_band = np.zeros((len(intervals), len(DOMAINS)), dtype=bool)
    for j, d in enumerate(DOMAINS):
        in_band[:, j] = np.abs(rpm - d) <= d * BAND

    segs = []
    for j, d in enumerate(DOMAINS):
        mask = in_band[:, j]
        i = 0
        while i < len(mask):
            if not mask[i]:
                i += 1
                continue
            k = i
            while k + 1 < len(mask) and mask[k + 1]:
                k += 1
            # intervals [i..k] are in-band; the run is defined over the *later*
            # pulse of each interval (backward-difference convention), so the
            # segment spans pulses[i+1 .. k+1] and n_pulses = k - i + 1.
            n_pulses = k - i + 1
            if n_pulses >= MIN_PULSES:
                segs.append({'domain': d, 'pi0': i + 1, 'pi1': k + 1,
                             'n_pulses': n_pulses, 'pulses': pulses[i + 1:k + 2]})
            i = k + 1

    out = []
    for s in segs:
        if s['n_pulses'] < KEEP_PULSES:
            continue
        # exact RPM: linear regression over the segment's pulse times
        # (verified bit-exact against the released steady-state segments)
        t = np.asarray(s['pulses']) / FS
        slope = np.polyfit(t, np.arange(len(t)), 1)[0]
        s['rpm_exact'] = 60.0 * slope
        s['start'] = int(s['pulses'][0])
        s['end'] = int(s['pulses'][-1])
        out.append(s)
    return out


def seg_name(stem: str, s) -> str:
    return f"{stem}_D_speed_{s['domain']}_rpm{s['rpm_exact']:.1f}_npulses{s['n_pulses']}.csv"


def process_file(raw_path: Path, out_dir: Path = None, steady_dir: Path = None,
                 verify: bool = False):
    stem = raw_path.stem
    df = pd.read_csv(raw_path, header=None)
    segs = extract_segments(df)
    print(f"{stem}: {len(segs)} segments kept")
    ok = True
    used_names = set()
    for s in segs:
        name = seg_name(stem, s)
        # guard against name collisions: two segments of the same recording may
        # round to identical rpm/npulses; append a suffix instead of overwriting
        if name in used_names:
            n = 2
            while f"{name[:-4]}_seg{n}.csv" in used_names:
                n += 1
            name = f"{name[:-4]}_seg{n}.csv"
        used_names.add(name)
        rows = s['end'] - s['start'] + 1
        print(f"  {name}  rows={rows}")
        if verify:
            ref = steady_dir / name
            if not ref.exists():
                print(f"    [MISS] no matching steady file")
                ok = False
                continue
            ref_rows = sum(1 for _ in open(ref, 'rb'))
            if ref_rows != rows:
                print(f"    [DIFF] rows: ref={ref_rows} vs new={rows}")
                ok = False
                continue
            ref_df = pd.read_csv(ref, header=None)
            new_df = df.iloc[s['start']:s['end'] + 1].reset_index(drop=True)
            same = np.allclose(ref_df.values.astype(float),
                               new_df.values.astype(float), atol=1e-9)
            print(f"    [{'OK' if same else 'DATA-DIFF'}] content comparison")
            ok = ok and same
        elif out_dir is not None:
            seg_df = df.iloc[s['start']:s['end'] + 1]
            seg_df.to_csv(out_dir / name, header=False, index=False)
    return ok


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--raw-dir', default=os.environ.get('MCC5_RAW', './raw_data'))
    ap.add_argument('--out-dir', default='./steady_csv')
    ap.add_argument('--steady-dir', default=None, help='existing steady_csv for verification')
    ap.add_argument('--file', default=None, help='process a single raw CSV filename')
    ap.add_argument('--verify', action='store_true')
    args = ap.parse_args()

    raw_dir = Path(args.raw_dir)
    out_dir = Path(args.out_dir)
    files = [raw_dir / args.file] if args.file else sorted(
        f for f in raw_dir.glob('*.csv') if 'speed_circulation' in f.name)
    print(f"Raw files to process: {len(files)}")
    if not args.verify:
        out_dir.mkdir(parents=True, exist_ok=True)

    all_ok = True
    t0 = time.time()
    for f in files:
        ok = process_file(f, out_dir if not args.verify else None,
                          Path(args.steady_dir) if args.steady_dir else None,
                          verify=args.verify)
        all_ok = all_ok and ok
    print(f"\nTotal time: {time.time()-t0:.1f}s")
    print("VERIFY RESULT:", "ALL MATCH" if (args.verify and all_ok) else
          ("MISMATCH FOUND" if args.verify else "extraction done"))


if __name__ == '__main__':
    main()
