# -*- coding: utf-8 -*-
"""Regenerate data/per_class_optimal_multiseed.json from multi_seed_results_full.json (n=5).
Structure preserved from the n=3 version: per-class means (fractions, leave-3000),
per-class optimal config, oracle/macro accuracies, note.
"""
import json, io
import numpy as np

CLASSES = ["health", "inner", "outer", "ball", "winding", "static_ec",
           "dynamic", "broken_bar", "voltage", "bend"]
CONFIGS = ["vib_Z", "vib_XYZ", "cur_ABC", "vibcur_6ch", "dual_branch"]
SEEDS = [42, 123, 456, 789, 1011]

raw = json.load(io.open("data/multi_seed_results_full.json", encoding="utf-8"))
runs = raw["runs"] if isinstance(raw, dict) and "runs" in raw else raw

per_class = {}
for cfg in CONFIGS:
    recs = [r for r in runs if r.get("scenario") == "leave_3000" and r.get("config") == cfg]
    got = sorted(r["seed"] for r in recs)
    assert got == SEEDS, f"{cfg}: seeds {got}"
    per_class[cfg] = {}
    for cl in CLASSES:
        vals = [r["per_class"][cl] for r in recs]
        per_class[cfg][cl] = float(np.mean(vals)) / 100.0 if np.mean(vals) > 1.5 else float(np.mean(vals))

# normalise: per_class in source JSON is in percent -> store fraction
optimal = {}
for cl in CLASSES:
    best_cfg = max(CONFIGS, key=lambda c: (per_class[c][cl], -CONFIGS.index(c)))
    optimal[cl] = best_cfg

oracle = float(np.mean([per_class[optimal[cl]][cl] for cl in CLASSES]))
macro = {c: float(np.mean([per_class[c][cl] for cl in CLASSES])) for c in CONFIGS}

out = {
    "per_class": per_class,
    "optimal": optimal,
    "oracle_acc": oracle,
    "vibcur_acc": macro["vibcur_6ch"],
    "vibZ_acc": macro["vib_Z"],
    "dual_acc": macro["dual_branch"],
    "note": "Multi-seed means (n=5, seeds 42/123/456/789/1011, 30 epochs, best-epoch), leave-3000. Source: multi_seed_results_full.json",
}
io.open("data/per_class_optimal_multiseed.json", "w", encoding="utf-8").write(json.dumps(out, indent=1))
print("oracle", round(oracle * 100, 2), "| macro:", {k: round(v * 100, 2) for k, v in macro.items()})
print("optimal:", optimal)
