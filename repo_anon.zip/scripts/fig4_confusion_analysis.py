"""
Fig 4: Confusion analysis — real waveforms (vib_Z + cur_A) and accuracy comparison.
Under single-channel vib_Z, broken-bar and static-eccentricity detection is
seed-dependent (large error bars: 82.6+/-24.5% and 91.8+/-9.1%); radial channels or
three-phase current stabilize them, and 6-channel fusion is deterministic (sigma=0)
for all three classes.
Layout: 3 rows (faults) × 3 columns (vib_Z, cur_A, accuracy)
Data: data/multi_seed_results_full.json (leave_3000, n=5 seeds 42/123/456/789/1011;
      bars show mean +/- 1 s.d., same source as Table tab:perclass)
"""
from fig_common import *; style(0.9)
import json, statistics
FS=12800

_full = load_json('multi_seed_results_full.json')

def cell_stats(cfg, cls):
    vals = [e['per_class'][cls] for e in _full
            if e['scenario'] == 'leave_3000' and e['config'] == cfg]
    assert len(vals) == 5, f'{cfg}/{cls}: expected 5 seeds, got {len(vals)}'
    return statistics.mean(vals) * 1.0, statistics.stdev(vals)

# Waveform snippets plotted below were extracted once from the dataset by
# extract_fig_waveforms.py and ship with the repo (raw CSVs are not
# distributed). We NEVER synthesize substitute data: missing JSON -> stop.
_sig4_path = DATA / 'fig4_signals.json'
if not _sig4_path.exists():
    raise SystemExit(
        f'FATAL: {_sig4_path} not found. Either restore the shipped data/fig4_signals.json '
        'or re-extract from the raw dataset: set MCC5_ROOT and run '
        '`cd scripts && python extract_fig_waveforms.py`.')
_sig4 = load_json('fig4_signals.json')
fkeys=['static_ec','broken_bar','bend']
flabs=['Static Eccentricity','Broken Bar','Bent Shaft']
fcols=[C['blue'],C['orange'],C['green']]

bar_cfgs = ['vib_Z', 'vib_XYZ', 'cur_ABC', 'vibcur_6ch']
bar_cols = [C['blue'], C['red'], C['orange'], C['green']]

fig = plt.figure(figsize=(7.0,5.0))

col_centers = [0.14, 0.37, 0.73]
col_headers = ['vib$_Z$ Waveform', 'cur$_A$ Waveform', 'leave-3000 Accuracy (%)']
for cx, ch in zip(col_centers, col_headers):
    fig.text(cx, 0.90, ch, ha='center', va='bottom', fontsize=7, fontweight='bold')

for row,(fk,fl,fc) in enumerate(zip(fkeys,flabs,fcols)):
    rec = _sig4[fk]
    v_raw=np.asarray(rec['vib_Z_raw'],dtype=float); v_=(v_raw-v_raw.mean())/(v_raw.std()+1e-8)
    c_raw=np.asarray(rec['cur_A_raw'],dtype=float); c_=(c_raw-c_raw.mean())/(c_raw.std()+1e-8)
    t=np.arange(2048)/FS*1000

    step=0.27
    ax = fig.add_axes([0.04,0.08+row*step,0.2,0.22])
    ax.plot(t,v_,color=fc,lw=0.5)
    ax.set_xlim(0,160); ax.set_ylim(-4,4); ax.tick_params(labelsize=5)
    ax.tick_params(labelbottom=False)
    ax.set_ylabel(fl,fontsize=5.5,fontweight='bold')
    ax.text(0.98,0.95,f'raw σ={np.std(v_raw):.3f} m/s$^2$',transform=ax.transAxes,fontsize=4.5,
            color=fc,ha='right',va='top')
    ax.grid(True,alpha=0.15,lw=0.3)

    ax = fig.add_axes([0.27,0.08+row*step,0.2,0.22])
    ax.plot(t,c_,color=C['red'],lw=0.5)
    ax.set_xlim(0,160); ax.set_ylim(-4,4); ax.tick_params(labelsize=5)
    ax.tick_params(labelbottom=False)
    ax.text(0.98,0.95,f'raw σ={np.std(c_raw):.2f} A',transform=ax.transAxes,fontsize=4.5,
            color=C['red'],ha='right',va='top')
    ax.grid(True,alpha=0.15,lw=0.3)

    ax = fig.add_axes([0.53,0.08+row*step,0.40,0.22])
    stats = [cell_stats(cfg, fk) for cfg in bar_cfgs]
    means = [s[0] for s in stats]
    stds  = [s[1] for s in stats]
    bars=ax.bar([0,1,2,3], means, yerr=stds, capsize=2,
                color=bar_cols, width=0.5, edgecolor='white', lw=0.3,
                error_kw=dict(lw=0.6, ecolor='0.25'))
    if row == 2:
        ax.set_xticks([0,1,2,3])
        ax.set_xticklabels(['vib$_Z$\n1ch','vib$_{XYZ}$\n3ch','cur$_{ABC}$\n3ch','6ch\nfusion'],fontsize=5)
    else:
        ax.set_xticks([])
    ax.set_ylim(0,118); ax.tick_params(labelsize=5)
    for b,mu,sd in zip(bars,means,stds):
        ax.text(b.get_x()+b.get_width()/2, min(mu+sd+3.5, 112), f'{mu:.1f}',
               ha='center',fontsize=6,fontweight='bold')
    ax.grid(True,axis='y',alpha=0.15,lw=0.3)

for cx in [0.14, 0.37]:
    fig.text(cx, 0.02, 'Time (ms)', ha='center', va='bottom', fontsize=6.5)

save('fig4_confusion_analysis',fig)
