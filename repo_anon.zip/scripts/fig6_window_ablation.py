"""Figure: Window ablation (P2-3), multi-seed upgrade (2026-07-30).

Data: data/window_ablation_multiseed_summary.json (leave-500, 6ch, n=3 seeds 42/123/456, 25 epochs).
Mean +/- std with per-seed points.
"""
import sys, json, numpy as np
sys.path.insert(0, '.')
from fig_common import *  # run from the scripts/ directory

style(1.0)

SR = 12800
s = load_json('window_ablation_multiseed_summary.json')
ws = np.array(sorted(int(k) for k in s))
mean = np.array([s[str(w)]['mean'] for w in ws])
std = np.array([s[str(w)]['std'] for w in ws])
seeds = np.array([s[str(w)]['values'] for w in ws])  # (3 windows, 3 seeds)

fig, ax = plt.subplots(figsize=(4, 3))
ax.errorbar(ws, mean, yerr=std, fmt='-o', color=C['blue'], linewidth=1.8,
            markersize=8, markerfacecolor=C['blue'], markeredgecolor='white',
            markeredgewidth=0.8, capsize=4, elinewidth=1.2, zorder=3)
# per-seed jittered points
rng = np.random.default_rng(0)
for j in range(seeds.shape[1]):
    ax.scatter(ws + rng.uniform(-150, 150, len(ws)), seeds[:, j],
               s=14, color=C['blue'], alpha=0.35, zorder=2)

ax.axhline(y=mean[0], color=C['red'], linestyle=':', linewidth=1, alpha=0.5)

for w, m, sd in zip(ws, mean, std):
    ax.annotate(f'{m:.1f}$\\pm${sd:.1f}', (w, m + sd), textcoords='offset points',
                xytext=(0, 9), ha='center', fontsize=8, fontweight='bold', color=C['blue'])

ax.set_xlabel('Window Length (samples)')
ax.set_ylabel('Accuracy (%)')
ax.set_xticks(ws)
ax.set_xticklabels([f'{w}\n({w*1000/SR:.0f}ms)' for w in ws])
ax.set_ylim(66, 81)

save('fig6_window_ablation')
print('fig6_window_ablation (multi-seed)  OK')
