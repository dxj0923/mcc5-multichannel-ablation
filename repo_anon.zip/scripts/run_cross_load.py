"""
P3-6: Cross-Load Robustness Analysis.
Evaluates 6ch early fusion on leave-3000 separately for 20Nm and 40Nm loads.
Loads from raw CSV files with single-pass preprocessing + tqdm progress.

Two-phase design:
  Phase 1 (one-time): Preprocess all CSVs -> per-file .npy cache + meta.json
  Phase 2 (per load): Load cached arrays, window, train

Usage: python scripts/run_cross_load.py
Output: ../data/cross_load_results.json, figures/fig7_cross_load.{pdf,png}
"""
import os
import sys, os, time, json, re, hashlib, numpy as np, pandas as pd
from pathlib import Path

STEADY_CSV = Path(os.environ.get('MCC5_ROOT', './raw_data')) / 'steady_csv'
CACHE_DIR = Path('data/preprocessed_csv')
SOURCE_DOMAINS = [500, 1000, 1500, 2000, 2500]
TARGET_DOMAIN = [3000]
EPOCHS = 25

FAULT_TO_ORIGINAL = {
    'health': 0,
    'bearing_inner_H': 1, 'bearing_inner_L': 2,
    'bearing_outer_H': 3, 'bearing_outer_L': 4,
    'bearing_ball_H': 5, 'bearing_ball_L': 5,
    'winding_H': 6, 'winding_L': 7,
    'static_eccentricity_H': 8, 'static_eccentricity_L': 9,
    'dynamic_eccentricity': 10,
    'broken_bar': 11,
    'voltage_unbalance_L': 12,
    'bend': 13,
}
LABEL_MERGE = {0:0, 1:1, 2:1, 3:2, 4:2, 5:3, 6:4, 7:4, 8:5, 9:5, 10:6, 11:7, 12:8, 13:9}
MERGE_NAME = {0:'Health',1:'Inner',2:'Outer',3:'Ball',4:'Winding',
              5:'StaticEC',6:'Dynamic',7:'BrokenBar',8:'Voltage',9:'Bend'}

def parse_fault(fstem):
    parts = fstem.split('_')
    cond_idx = None
    for i, p in enumerate(parts):
        if p in ('speed', 'torque'):
            if i+1 < len(parts) and parts[i+1] == 'circulation':
                cond_idx = i; break
    if cond_idx is None: return None, None
    fault_str = '_'.join(parts[:cond_idx])
    if '_and_' in fault_str: return None, None
    orig = FAULT_TO_ORIGINAL.get(fault_str)
    if orig is None: return None, None
    return LABEL_MERGE.get(orig), fault_str

def parse_torque(fstem):
    for p in fstem.split('_'):
        if p.endswith('Nm'):
            try: return int(p.replace('Nm', ''))
            except: pass
    return None

def parse_domain(fstem):
    m = re.search(r'_D_speed_(\d+)_rpm', fstem)
    if m: return int(m.group(1))
    return None

def file_hash(fpath):
    return hashlib.md5(str(fpath).encode()).hexdigest()[:12]

# ============ Phase 1: Build Cache (shared with window_ablation) ============
CACHE_DIR.mkdir(parents=True, exist_ok=True)
meta_path = CACHE_DIR / 'meta.json'

if meta_path.exists():
    print('Loading preprocessed cache...', flush=True)
    with open(meta_path) as f:
        cache_meta = json.load(f)
    cache_ok = all((CACHE_DIR / e['npy']).exists() for e in cache_meta)
    if not cache_ok:
        print('  Cache incomplete, rebuilding...', flush=True)
        cache_meta = None

if not meta_path.exists() or cache_meta is None:
    print('Phase 1: Preprocessing all CSV files...', flush=True)
    cache_meta = []
    csv_files = sorted(STEADY_CSV.glob('*.csv'))
    n_total = len(csv_files)
    t_start = time.time()

    for idx, f in enumerate(csv_files):
        domain = parse_domain(f.stem)
        torque = parse_torque(f.stem)
        fault_label, _ = parse_fault(f.stem)
        if None in (domain, torque, fault_label):
            continue

        try:
            df = pd.read_csv(f, header=None, skiprows=1, usecols=[3,4,5,6,7,8])
        except Exception as e:
            print(f'  WARN: failed to read {f.name}: {e}', flush=True)
            continue

        arr = df.values.astype(np.float32)
        # Save raw; per-window Z-score happens in Phase 2

        h = file_hash(f)
        npy_name = f'{domain}_{torque}Nm_{h}.npy'
        npy_path = CACHE_DIR / npy_name
        np.save(str(npy_path), arr)

        cache_meta.append({
            'npy': npy_name, 'domain': domain,
            'torque': torque, 'fault_label': fault_label,
            'samples': len(arr), 'file': f.name
        })

        if (idx + 1) % 50 == 0 or idx == n_total - 1:
            elapsed = time.time() - t_start
            print(f'  [{idx+1}/{n_total}] {elapsed:.0f}s elapsed', flush=True)

    with open(meta_path, 'w') as f:
        json.dump(cache_meta, f, indent=2)
    print(f'  Done: {len(cache_meta)} files cached ({time.time()-t_start:.0f}s)', flush=True)

# ============ Phase 2: Train per load ============
import torch, torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader
DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f'\nDevice: {DEVICE}', flush=True)

def cache_to_windows(domain_list, torque_filter):
    """Load cached raw npy arrays, window, then Z-score per window (matching baseline)."""
    X, y = [], []
    entries = [e for e in cache_meta if e['domain'] in domain_list]
    entries = [e for e in entries if e['torque'] == torque_filter]
    for e in entries:
        arr = np.load(str(CACHE_DIR / e['npy']))
        if len(arr) < 2048: continue
        n_win = len(arr) // 2048
        trimmed = arr[:n_win * 2048].reshape(-1, 2048, 6).transpose(0, 2, 1)
        m = trimmed.mean(axis=2, keepdims=True)
        s = trimmed.std(axis=2, keepdims=True) + 1e-8
        trimmed = (trimmed - m) / s
        X.append(trimmed)
        y.append(np.full(n_win, e['fault_label']))
    if not X: return np.zeros((0, 6, 2048)), np.zeros(0, dtype=np.int64)
    return np.concatenate(X), np.concatenate(y)

class TinyCNN(nn.Module):
    def __init__(self, in_c=6, n_cls=10):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_c,32,15,padding=7,bias=False), nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32,64,11,padding=5,bias=False), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64,128,9,padding=4,bias=False), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128,256,7,padding=3,bias=False), nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(256,256,5,padding=2,bias=False), nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Dropout(0.3),
            nn.Linear(256,128), nn.ReLU(), nn.Dropout(0.3), nn.Linear(128,n_cls))
    def forward(self, x): return self.net(x)

results = {}

for torque_name, torque_val in [('20Nm', 20), ('40Nm', 40)]:
    print(f'\n=== Cross-load: train on mixed, test on {torque_name} ===', flush=True)

    print('Loading source data (all loads, all source domains)...', flush=True)
    X_src_list, y_src_list = [], []
    for tq in [20, 40]:
        X, y = cache_to_windows(SOURCE_DOMAINS, tq)
        if len(X) > 0:
            X_src_list.append(X); y_src_list.append(y)
        print(f'  Source load={tq}Nm: {X.shape}', flush=True)
    if not X_src_list:
        print(f'  No source data loaded', flush=True); continue
    X_src = np.concatenate(X_src_list)
    y_src = np.concatenate(y_src_list)
    print(f'  Source combined: {X_src.shape}', flush=True)

    print(f'Loading test data ({torque_name})...', flush=True)
    X_tgt, y_tgt = cache_to_windows(TARGET_DOMAIN, torque_val)
    print(f'  Target: {X_tgt.shape}', flush=True)
    if len(X_tgt) == 0:
        print(f'  No test data, skipping', flush=True); continue

    t0 = time.time()
    torch.manual_seed(42); np.random.seed(42)
    dl_src = DataLoader(TensorDataset(torch.from_numpy(X_src).float(), torch.from_numpy(y_src).long()),
                        256, shuffle=True, drop_last=True, pin_memory=True)
    dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tgt).float(), torch.from_numpy(y_tgt).long()),
                        512, shuffle=False, pin_memory=True)
    model = TinyCNN(in_c=6, n_cls=10).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    best, best_preds, best_labels = 0.0, None, None
    for ep in range(EPOCHS):
        model.train()
        for xb, yb in dl_src:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
        sched.step()
        model.eval()
        correct, ap, al = 0, [], []
        with torch.no_grad():
            for xb, yb in dl_tgt:
                p = model(xb.to(DEVICE)).argmax(1)
                correct += p.eq(yb.to(DEVICE)).sum().item()
                ap.append(p.cpu()); al.append(yb)
        acc = correct / len(dl_tgt.dataset)
        if acc > best: best = acc; best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
        if (ep + 1) % 5 == 0:
            print(f'  epoch {ep+1}/{EPOCHS} best={best*100:.2f}%', flush=True)
    pc = {}
    for c in range(10):
        mask = best_labels == c
        pc[MERGE_NAME[c]] = round(float((best_preds[mask]==c).mean())*100, 2) if mask.sum()>0 else 0.0
    elapsed = time.time()-t0
    results[torque_name] = {'overall': round(float(best)*100,2), 'per_class': pc, 'elapsed_s': round(elapsed,1)}
    print(f'  Overall: {best*100:.2f}% ({elapsed:.0f}s)', flush=True)

with open('data/cross_load_results.json','w') as f:
    json.dump(results, f, indent=2)
print(f'\nResults saved', flush=True)

# ---- Figure ----
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

if len(results) >= 2:
    fig, axes = plt.subplots(1, 2, figsize=(8, 4))
    for ax, (name, data) in zip(axes, results.items()):
        classes = list(data['per_class'].keys())
        vals = list(data['per_class'].values())
        colors = ['#E69F00' if v < 80 else '#56B4E9' if v < 95 else '#009E73' for v in vals]
        ax.bar(classes, vals, color=colors)
        ax.set_title(f'{name} (overall: {data["overall"]}%)')
        ax.set_ylabel('Accuracy (%)')
        ax.set_ylim(0, 105)
        ax.tick_params(axis='x', rotation=45)
        ax.axhline(y=data['overall'], color='red', linestyle='--', linewidth=1, label=f'Avg: {data["overall"]}%')
        ax.legend(fontsize=8)
    fig.tight_layout()
FIGDIR = Path(__file__).resolve().parent.parent / 'figures'
FIGDIR.mkdir(exist_ok=True)
plt.savefig(FIGDIR / 'fig7_cross_load.pdf', dpi=200, bbox_inches='tight')
plt.savefig(FIGDIR / 'fig7_cross_load.png', dpi=200, bbox_inches='tight')
print(f'Figure saved to {FIGDIR}/fig7_cross_load.*', flush=True)
