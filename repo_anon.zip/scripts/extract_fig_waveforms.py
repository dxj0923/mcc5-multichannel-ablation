"""
Extract the exact waveform snippets used by fig4/fig5 and save them as JSON.

Why this exists: the raw steady-state CSVs are NOT shipped with the repository
(they derive from the public MCC5-THU dataset). To keep fig4/fig5 fully
reproducible for anyone who clones the repo, the precise samples plotted are
extracted once (this script, requires MCC5_ROOT) and shipped in
data/fig4_signals.json / data/fig5_signals.json. The figure scripts read the
JSON and fail loudly if it is missing — they never synthesize substitute data.

Re-extract (with dataset access):
    set MCC5_ROOT=<dataset root>   :: or export MCC5_ROOT=...
    cd scripts && python extract_fig_waveforms.py
"""
from fig_common import *  # provides CSV, load_csv, ROOT, np, pd, Path
import json

OUT4 = ROOT / 'data' / 'fig4_signals.json'
OUT5 = ROOT / 'data' / 'fig5_signals.json'

# --- fig5: vib_Z snippets (1024 raw samples, col 5) at 500/3000 rpm ----------
# display key -> exact filename prefix (severity variant made explicit: where
# both H/L variants exist we plot the high-severity one, deterministically)
FIG5_FAULTS = {'health': 'health', 'broken_bar': 'broken_bar',
               'bend': 'bend', 'winding': 'winding_h'}
SPEEDS6 = [500, 1000, 1500, 2000, 2500, 3000]

fig5 = {'snippets': {}, 'panel_c_sigma': {}}
for fn, prefix in FIG5_FAULTS.items():
    fig5['snippets'][fn] = {}
    for speed in (500, 3000):
        df = load_csv(prefix, str(speed))
        if df is None or df.shape[1] < 6:
            raise SystemExit(f'FATAL: no CSV for {prefix} at {speed} rpm — cannot extract fig5 signals')
        v = df.iloc[:1024, 5].values.astype(float)
        fig5['snippets'][fn][str(speed)] = {
            'vib_Z_raw': [round(float(x), 6) for x in v],
            'raw_std': round(float(v.std()), 6),
            'n': int(len(v)),
        }

# panel (c): mean raw vib_Z sigma over ALL single-fault segments per exact speed
def raw_sigma(prefix, speed):
    tok = f'_d_speed_{speed}_rpm'
    sig = []
    for f in sorted(CSV.glob('*.csv')):
        name = f.name.lower()
        if not name.startswith(prefix + '_speed_circulation') or tok not in name:
            continue
        df = pd.read_csv(f, nrows=4096, header=None)
        if df.shape[1] >= 6:
            sig.append(df.iloc[:, 5].values.astype(float).std())
    return float(np.mean(sig)) if sig else None

for fn, prefix in FIG5_FAULTS.items():
    fig5['panel_c_sigma'][fn] = {str(s): raw_sigma(prefix, s) for s in SPEEDS6}
    missing = [s for s in SPEEDS6 if fig5['panel_c_sigma'][fn][str(s)] is None]
    if missing:
        raise SystemExit(f'FATAL: {prefix} missing speeds {missing} — cannot extract fig5 panel (c)')

# --- all single-fault types x 6 speeds (provenance for the paper's -----------
# "15-fold amplitude collapse" claim; audited by scripts/_audit_prose.py) -----
import re as _re2
all_types = {}
for f in sorted(CSV.glob('*.csv')):
    name = f.name.lower()
    if '_d_speed_' not in name:
        continue
    base = name.split('_speed_circulation')[0]
    if 'and' in base:
        continue  # multi-fault segments
    m = _re2.search(r'_d_speed_(\d+)_rpm', name)
    all_types.setdefault(base, {}).setdefault(int(m.group(1)), []).append(f)

fig5['all_types_sigma'] = {}
for fault, sp in sorted(all_types.items()):
    row = {}
    for s in SPEEDS6:
        sig = []
        for f in sp.get(s, []):
            df = pd.read_csv(f, nrows=4096, header=None)
            if df.shape[1] >= 6:
                sig.append(df.iloc[:, 5].values.astype(float).std())
        row[str(s)] = round(float(np.mean(sig)), 6) if sig else None
    fig5['all_types_sigma'][fault] = row

with open(OUT5, 'w') as f:
    json.dump(fig5, f)
print(f'Saved {OUT5}')

# --- fig4: vib_Z + cur_A snippets (2048 raw samples, cols 5/6) at 3000 rpm ---
FIG4_FAULTS = {'static_ec': 'static_eccentricity_h', 'broken_bar': 'broken_bar', 'bend': 'bend'}
fig4 = {}
for fk, fname in FIG4_FAULTS.items():
    df = load_csv(fname, '3000')
    if df is None or df.shape[1] < 7:
        raise SystemExit(f'FATAL: no CSV for {fname} at 3000 rpm — cannot extract fig4 signals')
    v = df.iloc[:2048, 5].values.astype(float)
    c = df.iloc[:2048, 6].values.astype(float)
    fig4[fk] = {
        'vib_Z_raw': [round(float(x), 6) for x in v],
        'cur_A_raw': [round(float(x), 6) for x in c],
        'n': int(len(v)),
    }

with open(OUT4, 'w') as f:
    json.dump(fig4, f)
print(f'Saved {OUT4}')

# --- console summary for verification ---------------------------------------
print('\nfig5 raw sigma (m/s^2):')
for fn in FIG5_FAULTS:
    s = fig5['panel_c_sigma'][fn]
    print(f'  {fn:12s} 500rpm={s["500"]:.4f}  3000rpm={s["3000"]:.4f}  '
          f'ratio={s["3000"] / s["500"]:.1f}x')
m500 = np.mean([fig5['panel_c_sigma'][fn]['500'] for fn in FIG5_FAULTS])
m3000 = np.mean([fig5['panel_c_sigma'][fn]['3000'] for fn in FIG5_FAULTS])
print(f'  mean over 4 faults: 500rpm={m500:.4f}  3000rpm={m3000:.4f}  ratio={m3000 / m500:.1f}x')

# all-types summary (paper claim: ~15-fold collapse, per-type 10-26x)
rows = fig5['all_types_sigma']
v500 = [r['500'] for r in rows.values() if r['500']]
v3000 = [r['3000'] for r in rows.values() if r['3000']]
rats = [r['3000'] / r['500'] for r in rows.values() if r['500'] and r['3000']]
print(f'\nall-types ({len(rows)}): mean 500rpm={np.mean(v500):.4f}  3000rpm={np.mean(v3000):.4f}'
      f'  ratio={np.mean(v3000) / np.mean(v500):.1f}x  per-type range {min(rats):.1f}-{max(rats):.1f}x')
