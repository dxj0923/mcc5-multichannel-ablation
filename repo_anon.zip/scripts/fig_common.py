"""
Shared infrastructure for all paper figures.

== ADJUSTABLE SETTINGS ==
  - style(scale): scale font sizes globally (default 1.0; try 0.8, 1.2)
  - C dict: Okabe-Ito color palette — change any hex value
  - save(DPI): edit save() to change PDF/PNG/SVG resolution
  - CLASSES / LABS: class IDs and display labels
  - box() / arr(): helper fontsize, color, linewidth params
"""
import os
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from pathlib import Path
import json, os, numpy as np, pandas as pd, warnings
warnings.filterwarnings('ignore')

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
FIG  = ROOT / 'figures'
FIG.mkdir(exist_ok=True)  # clean clones have no figures/ dir; save() would crash otherwise
CSV  = Path(os.environ.get('MCC5_ROOT', './raw_data')) / 'steady_csv'

def load_json(name):
    return json.loads((DATA / name).read_bytes())

# Okabe-Ito colorblind-safe palette (10 colors)
# == CHANGE COLORS HERE == replace any hex value
C = dict(blue='#0072B2', orange='#E69F00', green='#009E73',
         red='#D55E00', purple='#CC79A7', yellow='#F0E442',
         black='#000000', gray='#999999', cyan='#56B4E9')

def style(scale=1.0):
    """Apply publication style.
       scale=1.0 → base font 8pt. Increase (1.2) for larger text, decrease (0.8) for denser.
    """
    fs = 8 * scale
    plt.rcParams.update({
        'font.family': 'serif',
        'font.serif': ['Times New Roman', 'DejaVu Serif', 'serif'],
        # === FONT SIZES (all controlled by 'scale') ===
        'font.size': fs, 'axes.titlesize': fs+1, 'axes.labelsize': fs,
        'xtick.labelsize': fs-1, 'ytick.labelsize': fs-1,
        'legend.fontsize': fs-1,
        # === FIGURE APPEARANCE ===
        'figure.facecolor': 'white', 'axes.facecolor': 'white',
        'axes.edgecolor': '#333', 'axes.linewidth': 0.6,
        'axes.grid': True, 'axes.grid.axis': 'y', 'grid.color': '#ddd', 'grid.linewidth': 0.4,
        'axes.spines.top': False, 'axes.spines.right': False,
        'xtick.direction': 'out', 'ytick.direction': 'out',
        'xtick.color': '#333', 'ytick.color': '#333',
        'lines.linewidth': 1.0, 'lines.markersize': 4,
        'savefig.dpi': 200, 'savefig.bbox': 'tight', 'savefig.pad_inches': 0.05,
    })

def save(name, fig=None):
    """Save figure as PDF + PNG (600 DPI) + SVG. Change DPI here."""
    if fig is None: fig = plt.gcf()
    fig.savefig(FIG / f'{name}.pdf', dpi=200)
    fig.savefig(FIG / f'{name}.png', dpi=600)  # <- change 600 to lower for smaller files
    fig.savefig(FIG / f'{name}.svg', dpi=200)
    plt.close(fig); print(f'  {name}  OK')

import re as _re

def load_csv(fault, speed_str='3000', single=True):
    """Load one steady-state segment CSV for `fault` at an EXACT segment speed.

    Filenames look like
      <faults>_speed_circulation_20Nm_<NOMINAL>rpm_<ts>_D_speed_<SEG>_rpm<meas>_npulses<N>.csv
    Two exactness rules (both were once bugs):
      * fault is matched as a full filename PREFIX ('<fault>_speed_circulation'),
        never as a substring -- pass the severity variant explicitly
        ('winding_h', not 'winding'), otherwise the H/L variant picked is
        whatever happens to sort first;
      * segment speed is parsed from the '_D_speed_<seg>_rpm' token, never from
        the recording's nominal speed (1000/2000/3000) that appears earlier in
        the name.
    CSVs are headerless (consistent with the training pipeline). Returns None
    (with a printed warning) if no segment matches.
    """
    target = int(speed_str)
    prefix = fault.lower() + '_speed_circulation'
    ms = []
    for f in sorted(CSV.glob('*.csv')):
        name = f.name.lower()
        if not name.startswith(prefix):
            continue
        if single and 'and' in name.split('_speed_circulation')[0]:
            continue
        m = _re.search(r'_d_speed_(\d+)_rpm', name)
        if m and int(m.group(1)) == target:
            ms.append(f)
    if not ms:
        print(f'  WARNING load_csv: no segment for fault={fault!r} at segment speed {target} rpm')
        return None
    print(f'  load_csv({fault}, {target} rpm) -> {ms[0].name}')
    return pd.read_csv(ms[0], nrows=4096, header=None)

# Class display labels — change to rename axes/legends
CLASSES = ['health','inner','outer','ball','winding',
           'static_ec','dynamic','broken_bar','voltage','bend']
LABS = ['Health','Inner','Outer','Ball','Winding','sEC','Dyn','bBar','Volt','Bend']

def box(ax, x, y, w, h, text, color, fs=6.5, tc='white'):
    """Draw a rounded rectangle with text. Adjust fs for font size, color/fc for fill/text."""
    ax.add_patch(FancyBboxPatch((x-w/2, y-h/2), w, h, boxstyle='round,pad=0.06',
                                 facecolor=color, edgecolor='white', lw=1.2, zorder=3))
    ax.text(x, y, text, ha='center', va='center', fontsize=fs, color=tc, fontweight='bold', zorder=4)

def arr(ax, x1, y1, x2, y2, c='#555', lw=1.0):
    """Draw an arrow. Adjust c (color) and lw (line width)."""
    ax.annotate('', xy=(x2, y2), xytext=(x1, y1),
                arrowprops=dict(arrowstyle='->', color=c, lw=lw))
