"""
Fig 8 (feature-space version): sample-level t-SNE of penultimate features.

Two panels: (a) vib_Z single channel, (b) 6ch early fusion.
Points are target-domain test samples (leave-3000), colored by TRUE class;
misclassified samples are marked with black edges.

Requires: data/tsne_features.json (run experiment/run_tsne_features.py first).

Run from the scripts/ directory:
    python fig8_tsne_features.py
"""
from fig_common import *

style()
d = load_json('tsne_features.json')
labels = np.array(d['label_ids'])
class_names = d['class_names']

# Okabe-Ito-based 10-class palette (C has 9; add sky blue variant for the 10th)
palette = [C['blue'], C['orange'], C['green'], C['red'], C['purple'],
           C['yellow'], C['cyan'], '#882255', '#44AA99', C['gray']]

fig, axes = plt.subplots(1, 2, figsize=(7.0, 3.4))
for ax, key, title in [
    (axes[0], 'vib_Z', 'vib$_Z$ single channel'),
    (axes[1], 'vibcur_6ch', '6ch early fusion'),
]:
    emb = np.array(d[key]['embedding'])
    preds = np.array(d[key]['preds'])
    acc = d[key]['best_acc']
    for c in range(len(class_names)):
        m = labels == c
        ax.scatter(emb[m, 0], emb[m, 1], s=3, color=palette[c], alpha=0.55,
                   linewidths=0, rasterized=True)
    mis = preds != labels
    ax.scatter(emb[mis, 0], emb[mis, 1], s=6, facecolors='none',
               edgecolors='black', linewidths=0.4, alpha=0.7, rasterized=True)
    ax.set_title(f'({chr(97 if key=="vib_Z" else 98)}) {title} — {acc:.1f}%', fontsize=8)
    ax.set_xticks([]); ax.set_yticks([])
    ax.grid(False)

handles = [plt.Line2D([], [], marker='o', ls='', color=palette[i], markersize=4,
                      label=LABS[i]) for i in range(len(class_names))]
handles.append(plt.Line2D([], [], marker='o', ls='', markerfacecolor='none',
                          markeredgecolor='black', markersize=4, label='Miscl.'))
fig.legend(handles=handles, loc='lower center', ncol=11, frameon=False,
           fontsize=6.5, columnspacing=0.9, handletextpad=0.3)
fig.tight_layout(rect=[0, 0.08, 1, 1])
save('fig8_tsne_features', fig)
