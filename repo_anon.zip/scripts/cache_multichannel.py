"""
Cache ALL 6 signal channels (vib_XYZ + cur_ABC) for multi-channel fusion.
Domain × channel cache:
  cached_multichannel/domain_500.npz → {X: (N, 6, 2048), y: (N,)}
  channels: 0=vib_X, 1=vib_Y, 2=vib_Z, 3=cur_A, 4=cur_B, 5=cur_C
"""
import os
import numpy as np, pandas as pd, time, os
from pathlib import Path
from data_loader import parse_filename, ORIG_TO_CONTIGUOUS, sliding_window_zscore

_ROOT = Path(os.environ.get('MCC5_ROOT', './raw_data'))
STEADY_CSV = _ROOT / 'steady_csv'
CACHE_DIR = _ROOT / 'cached_multichannel'
CACHE_DIR.mkdir(parents=True, exist_ok=True)

WINDOW = 2048; STEP = 1024; ALL_DOMAINS = [500,1000,1500,2000,2500,3000]

domain_data = {d: [] for d in ALL_DOMAINS}
all_files = sorted(STEADY_CSV.glob('*.csv'))
print(f"Total files: {len(all_files)}")

t0 = time.time()
for f in all_files:
    meta = parse_filename(f.name)
    if meta['is_composite']:
        continue
    d = meta['domain']
    label = ORIG_TO_CONTIGUOUS.get(meta['label'], meta['label'])
    
    df = pd.read_csv(f, header=None)
    # Extract all 6 signal channels
    signals = df.iloc[:, 3:9].values.astype(np.float32)  # cols 3-8: vib_X,vib_Y,vib_Z,cur_A,cur_B,cur_C
    
    # Sliding window on ALL channels simultaneously
    n = len(signals)
    for start in range(0, n - WINDOW + 1, STEP):
        window = signals[start:start + WINDOW]  # (2048, 6)
        # Z-score each channel independently
        window = (window - window.mean(axis=0, keepdims=True)) / (window.std(axis=0, keepdims=True) + 1e-8)
        domain_data[d].append((window.T, label))  # (6, 2048), label

for d in ALL_DOMAINS:
    if not domain_data[d]:
        continue
    X_list, y_list = zip(*domain_data[d])
    X = np.stack(X_list, axis=0).astype(np.float32)  # (N, 6, 2048)
    y = np.array(y_list, dtype=np.int64)
    cache_file = CACHE_DIR / f'domain_{d}.npz'
    np.savez_compressed(cache_file, X=X, y=y)
    print(f"Domain {d:>4d}: {len(y):>6,d} windows, X={X.shape} -> {cache_file.name}")

print(f"Total time: {time.time()-t0:.1f}s")
print("Done!")
