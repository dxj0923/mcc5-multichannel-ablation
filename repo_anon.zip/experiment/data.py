"""Data loading from cached multi-channel NPZ files."""
import numpy as np
from config import CACHE_MULTI, LABEL_MERGE

def load_domains(domains):
    """Load cached multi-channel data for given list of domains.
    Returns (X, y) where X.shape = (N, 6, 2048), y.shape = (N,).
    Labels are merged from 14-class to 10-class.
    """
    Xs, ys = [], []
    for d in domains:
        f = CACHE_MULTI / f'domain_{d}.npz'
        if not f.exists():
            raise FileNotFoundError(f'Cache not found: {f}')
        data = np.load(f)
        Xs.append(data['X'])
        ys.append(np.array([LABEL_MERGE.get(int(l), int(l)) for l in data['y']]))
    return np.concatenate(Xs), np.concatenate(ys)

def select_channels(X, channels):
    """Select specific channel indices from multi-channel data.
    channels: list of ints, e.g. [2] for vib_Z, [0,1,2,3,4,5] for all 6.
    """
    return X[:, channels, :]
