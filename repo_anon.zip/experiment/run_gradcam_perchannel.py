"""
Per-channel attribution for the 6ch early-fusion model (leave-3000).

Extends the original Grad-CAM analysis (run_remaining_analysis.py, temporal-only)
with channel-resolved evidence for Section 4.8:

  1. Temporal Grad-CAM on 50 outer-race samples (reproduces existing result).
  2. Per-channel gradient x input attribution: for every target-domain sample,
     relevance_c = sum_t |d(score)/d(x_c,t) * x_c,t|, normalized per sample,
     averaged per true class -> 10 x 6 matrix (+ radial/axial/current groups).
  3. Leave-one-channel-out occlusion: accuracy drop when each channel (and the
     vib/cur groups) is zeroed, on the full test set and on outer race only.

Trains the same 6ch TinyCNN as the original Grad-CAM run (seed=42, EPOCHS=25).
Output: ../data/gradcam_perchannel_results.json

Run from the experiment/ directory of the D-drive repo:
    cd experiment
    python run_gradcam_perchannel.py

Estimated runtime: ~10 min on GPU.
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN

EPOCHS = 25
SEED = 42
CH_NAMES = ['vib_X', 'vib_Y', 'vib_Z', 'cur_A', 'cur_B', 'cur_C']
GROUPS = {'vib_radial': [0, 1], 'vib_axial': [2], 'cur_all': [3, 4, 5]}

# ===== 1. Train 6ch model (identical protocol to original Grad-CAM run) =====
torch.manual_seed(SEED); np.random.seed(SEED)
sc = SCENARIOS['leave_3000']
X_src, y_src = load_domains(sc['source'])
X_tgt, y_tgt = load_domains(sc['target'])
X_sc = select_channels(X_src, [0, 1, 2, 3, 4, 5])
X_tc = select_channels(X_tgt, [0, 1, 2, 3, 4, 5])
print(f'Data: src={X_sc.shape}, tgt={X_tc.shape}', flush=True)

dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(), torch.from_numpy(y_tgt).long()), 512, shuffle=False, pin_memory=True)

model = TinyCNN(in_c=6, n_cls=NUM_CLASSES).to(DEVICE)
opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
t0 = time.time()
for ep in range(EPOCHS):
    model.train()
    for xb, yb in dl_src:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
    sched.step()
    if (ep + 1) % 5 == 0:
        print(f'  epoch {ep+1}/{EPOCHS} ({time.time()-t0:.0f}s)', flush=True)
model.eval()

# baseline accuracy
def evaluate(X, y):
    dl = DataLoader(TensorDataset(torch.from_numpy(X).float(), torch.from_numpy(y).long()), 512, shuffle=False)
    correct, preds_all = 0, []
    with torch.no_grad():
        for xb, yb in dl:
            p = model(xb.to(DEVICE)).argmax(1)
            correct += p.eq(yb.to(DEVICE)).sum().item()
            preds_all.append(p.cpu())
    return correct / len(y), torch.cat(preds_all).numpy()

base_acc, base_preds = evaluate(X_tc, y_tgt)
outer_mask = y_tgt == 2
outer_acc_base = float((base_preds[outer_mask] == 2).mean())
print(f'Baseline: overall={base_acc*100:.2f}%  outer={outer_acc_base*100:.2f}%', flush=True)

# ===== 2. Temporal Grad-CAM (reproduce original, 50 outer-race samples) =====
print('Computing temporal Grad-CAM (50 outer-race samples)...', flush=True)
activations, gradients = {}, {}
target_layer = model.net[16]  # last Conv1d(256,256,5)
target_layer.register_forward_hook(lambda m, i, o: activations.__setitem__('out', o))
target_layer.register_full_backward_hook(lambda m, gi, go: gradients.__setitem__('out', go[0]))

outer_idx = np.where(outer_mask)[0][:50]
gcams = []
for idx in outer_idx:
    x = torch.from_numpy(X_tc[idx:idx + 1]).float().to(DEVICE)
    x.requires_grad_()
    logits = model(x)
    cls_idx = logits.argmax(1).item()
    model.zero_grad()
    logits[0, cls_idx].backward()
    act, grad = activations['out'][0], gradients['out'][0]
    cam = (grad.mean(dim=1, keepdim=True) * act).sum(dim=0).detach().cpu().numpy()
    cam = np.maximum(cam, 0)
    if cam.max() > 0: cam /= cam.max()
    gcams.append(cam)
mean_cam = np.array(gcams).mean(axis=0)

# ===== 3. Per-channel gradient x input attribution (all target samples) =====
print('Computing per-channel grad x input attribution (all test samples)...', flush=True)
rel_sum = np.zeros((NUM_CLASSES, 6))
rel_cnt = np.zeros(NUM_CLASSES)
n_total = len(y_tgt)
for idx in range(n_total):
    x = torch.from_numpy(X_tc[idx:idx + 1]).float().to(DEVICE)
    x.requires_grad_()
    logits = model(x)
    cls_idx = logits.argmax(1).item()
    model.zero_grad()
    logits[0, cls_idx].backward()
    g = x.grad[0].cpu().numpy()          # (6, 2048)
    xv = X_tc[idx]                        # (6, 2048), already z-scored
    rel = np.abs(g * xv).sum(axis=1)      # (6,)
    s = rel.sum()
    if s > 0: rel = rel / s
    c_true = int(y_tgt[idx])
    rel_sum[c_true] += rel
    rel_cnt[c_true] += 1
    if (idx + 1) % 500 == 0:
        print(f'  [{idx+1}/{n_total}]', flush=True)

per_class_channel = {}
for c in range(NUM_CLASSES):
    if rel_cnt[c] > 0:
        m = rel_sum[c] / rel_cnt[c]
        per_class_channel[MERGE_NAME[c]] = {
            **{CH_NAMES[i]: round(float(m[i]), 4) for i in range(6)},
            **{g: round(float(m[idxs].sum()), 4) for g, idxs in GROUPS.items()},
        }

print('\nPer-class channel attribution (normalized shares):', flush=True)
for cname, row in per_class_channel.items():
    print(f"  {cname:12s} radial={row['vib_radial']:.3f} axial={row['vib_axial']:.3f} cur={row['cur_all']:.3f}", flush=True)

# ===== 4. Leave-one-channel-out occlusion =====
print('\nOcclusion test (leave-one-channel/group-out)...', flush=True)
occlusion = {}
tests = {**{CH_NAMES[i]: [i] for i in range(6)}, 'vib_all': [0, 1, 2], 'cur_all': [3, 4, 5]}
for name, chs in tests.items():
    X_occ = X_tc.copy()
    X_occ[:, chs, :] = 0.0  # z-scored data: zero = per-window mean
    acc, preds = evaluate(X_occ, y_tgt)
    outer_acc = float((preds[outer_mask] == 2).mean())
    occlusion[name] = {
        'overall_acc': round(acc * 100, 2),
        'overall_drop': round((base_acc - acc) * 100, 2),
        'outer_acc': round(outer_acc * 100, 2),
        'outer_drop': round((outer_acc_base - outer_acc) * 100, 2),
    }
    print(f"  -{name:8s}: overall={acc*100:5.2f}% (drop {occlusion[name]['overall_drop']:5.2f})  "
          f"outer={outer_acc*100:5.2f}% (drop {occlusion[name]['outer_drop']:5.2f})", flush=True)

# ===== 5. Save =====
out = {
    'meta': {'scenario': 'leave_3000', 'seed': SEED, 'epochs': EPOCHS,
             'baseline_overall_acc': round(base_acc * 100, 2),
             'baseline_outer_acc': round(outer_acc_base * 100, 2),
             'n_test_samples': int(n_total)},
    'mean_gradcam_temporal': mean_cam.tolist(),
    'temporal_resolution': len(mean_cam),
    'per_class_channel_attribution': per_class_channel,
    'channel_names': CH_NAMES,
    'occlusion': occlusion,
    'note': 'grad x input attribution (predicted-class score), per-sample normalized; '
            'occlusion zeroes channels of z-scored inputs.',
}
with open('../data/gradcam_perchannel_results.json', 'w') as f:
    json.dump(out, f, indent=2)
print('\nSaved: ../data/gradcam_perchannel_results.json', flush=True)
