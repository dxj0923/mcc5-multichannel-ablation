"""
P1-1: Multi-seed ablation: 6 configs x 4 scenarios x 3 seeds + DualBranch.
Saves results to ../data/multi_seed_results.json
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN, DualBranchCNN

SEEDS = [42, 123, 456]
SCENARIOS_LIST = ['leave_3000', 'leave_500', 'low_to_high', 'high_to_low']
CH_CONFIGS = {
    'vib_Z': [2], 'vib_XY': [0,1], 'vib_XYZ': [0,1,2],
    'cur_ABC': [3,4,5], 'vib_XYZ_curA': [0,1,2,3], 'vibcur_6ch': [0,1,2,3,4,5],
}
EPOCHS = 30

results = []

for sc_name in SCENARIOS_LIST:
    sc = SCENARIOS[sc_name]
    print(f'\n{"="*60}\n{sc_name}: train {sc["source"]} -> test {sc["target"]}')
    X_src, y_src = load_domains(sc['source'])
    X_tgt, y_tgt = load_domains(sc['target'])

    for cfg_name, ch_idx in CH_CONFIGS.items():
        X_sc = select_channels(X_src, ch_idx)
        X_tc = select_channels(X_tgt, ch_idx)
        for seed in SEEDS:
            t0 = time.time()
            torch.manual_seed(seed); np.random.seed(seed)
            dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
            dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(), torch.from_numpy(y_tgt).long()), 512, shuffle=False, pin_memory=True)
            model = TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES).to(DEVICE)
            opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
            sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
            best, best_preds, best_labels = 0.0, None, None
            for ep in range(EPOCHS):
                model.train()
                for xb, yb in dl_src:
                    xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                    opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
                sched.step()
                model.eval(); correct = 0; ap, al = [], []
                with torch.no_grad():
                    for xb, yb in dl_tgt:
                        p = model(xb.to(DEVICE)).argmax(1)
                        correct += p.eq(yb.to(DEVICE)).sum().item()
                        ap.append(p.cpu()); al.append(yb)
                acc = correct / len(dl_tgt.dataset)
                if acc > best: best = acc; best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
            pc = {MERGE_NAME[c]: float((best_preds[best_labels==c]==c).mean()) for c in range(NUM_CLASSES) if (best_labels==c).sum()>0}
            for c in range(NUM_CLASSES):
                if (best_labels==c).sum() == 0: pc[MERGE_NAME[c]] = 0.0
            elapsed = time.time() - t0
            results.append({'scenario': sc_name, 'config': cfg_name, 'seed': seed,
                'best_acc': round(float(best)*100, 2),
                'per_class': {k: round(v*100, 2) for k,v in pc.items()},
                'elapsed_s': round(elapsed, 1)})
            mac = np.mean(list(pc.values())) * 100
            print(f'  {cfg_name:15s} seed={seed}: {best*100:.2f}% macro={mac:.2f}% ({elapsed:.0f}s)')

    # DualBranch (6ch)
    for seed in SEEDS:
        t0 = time.time()
        torch.manual_seed(seed); np.random.seed(seed)
        X_6sc = select_channels(X_src, CH_CONFIGS['vibcur_6ch'])
        X_6tc = select_channels(X_tgt, CH_CONFIGS['vibcur_6ch'])
        dl_src = DataLoader(TensorDataset(torch.from_numpy(X_6sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
        dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_6tc).float(), torch.from_numpy(y_tgt).long()), 512, shuffle=False, pin_memory=True)
        model = DualBranchCNN(n_cls=NUM_CLASSES).to(DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        best, best_preds, best_labels = 0.0, None, None
        for ep in range(EPOCHS):
            model.train()
            for xb, yb in dl_src:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
            sched.step()
            model.eval(); correct = 0; ap, al = [], []
            with torch.no_grad():
                for xb, yb in dl_tgt:
                    p = model(xb.to(DEVICE)).argmax(1)
                    correct += p.eq(yb.to(DEVICE)).sum().item()
                    ap.append(p.cpu()); al.append(yb)
            acc = correct / len(dl_tgt.dataset)
            if acc > best: best = acc; best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
        pc = {MERGE_NAME[c]: float((best_preds[best_labels==c]==c).mean()) for c in range(NUM_CLASSES) if (best_labels==c).sum()>0}
        for c in range(NUM_CLASSES):
            if (best_labels==c).sum() == 0: pc[MERGE_NAME[c]] = 0.0
        elapsed = time.time() - t0
        results.append({'scenario': sc_name, 'config': 'dual_branch', 'seed': seed,
            'best_acc': round(float(best)*100, 2),
            'per_class': {k: round(v*100, 2) for k,v in pc.items()},
            'elapsed_s': round(elapsed, 1)})
        mac = np.mean(list(pc.values())) * 100
        print(f'  dual_branch     seed={seed}: {best*100:.2f}% macro={mac:.2f}% ({elapsed:.0f}s)')

with open('../data/multi_seed_results.json', 'w') as f:
    json.dump(results, f, indent=2)
print(f'\nSaved multi-seed results ({len(results)} runs)')
