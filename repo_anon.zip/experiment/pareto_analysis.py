"""
P3-5: Compute FLOPs, params, inference latency for each configuration.
CPU only — no GPU needed.
"""
import sys, time, json
sys.path.insert(0, '.')
import torch
import torch.nn as nn

from config import DEVICE, NUM_CLASSES
from models import TinyCNN, DualBranchCNN

configs = {'vib_Z':1, 'vib_XY':2, 'vib_XYZ':3, 'cur_ABC':3, 'vib_XYZ_curA':4, 'vibcur_6ch':6}

results = []
for name, channels in configs.items():
    model = TinyCNN(in_c=channels, n_cls=NUM_CLASSES).to(DEVICE)
    model.eval()

    n_params = sum(p.numel() for p in model.parameters())
    dummy = torch.randn(1, channels, 2048).to(DEVICE)

    with torch.no_grad():
        model(dummy)

    # Warmup
    for _ in range(10):
        model(dummy)
    torch.cuda.synchronize() if DEVICE.type == 'cuda' else None

    n_warmup = 50
    n_iters = 200
    for _ in range(n_warmup):
        model(dummy)
    torch.cuda.synchronize() if DEVICE.type == 'cuda' else None

    starter = torch.cuda.Event(enable_timing=True) if DEVICE.type == 'cuda' else None
    ender = torch.cuda.Event(enable_timing=True) if DEVICE.type == 'cuda' else None

    if DEVICE.type == 'cuda':
        starter.record()
        for _ in range(n_iters):
            model(dummy)
        ender.record()
        torch.cuda.synchronize()
        latency_ms = starter.elapsed_time(ender) / n_iters
    else:
        t0 = time.perf_counter()
        for _ in range(n_iters):
            model(dummy)
        latency_ms = (time.perf_counter() - t0) / n_iters * 1000

    # Model size (32-bit float)
    model_bytes = n_params * 4  # float32
    model_kb = model_bytes / 1024

    results.append({
        'config': name,
        'channels': channels,
        'params': n_params,
        'model_kb': round(model_kb, 1),
        'latency_ms': round(latency_ms, 3),
    })
    print(f'{name:20s} ch={channels}  params={n_params:>7,d}  model={model_kb:>6.1f}KB  latency={latency_ms:.3f}ms')

# DualBranch
model = DualBranchCNN(n_cls=NUM_CLASSES).to(DEVICE)
model.eval()
n_params = sum(p.numel() for p in model.parameters())
dummy = torch.randn(1, 6, 2048).to(DEVICE)
with torch.no_grad():
    model(dummy)
for _ in range(10 + n_warmup):
    model(dummy)
torch.cuda.synchronize() if DEVICE.type == 'cuda' else None
if DEVICE.type == 'cuda':
    starter.record()
    for _ in range(n_iters):
        model(dummy)
    ender.record()
    torch.cuda.synchronize()
    latency_ms = starter.elapsed_time(ender) / n_iters
else:
    t0 = time.perf_counter()
    for _ in range(n_iters):
        model(dummy)
    latency_ms = (time.perf_counter() - t0) / n_iters * 1000

model_bytes = n_params * 4
model_kb = model_bytes / 1024
results.append({
    'config': 'dual_branch',
    'channels': 6,
    'params': n_params,
    'model_kb': round(model_kb, 1),
    'latency_ms': round(latency_ms, 3),
})
print(f'{"dual_branch":20s} ch=6  params={n_params:>7,d}  model={model_kb:>6.1f}KB  latency={latency_ms:.3f}ms')

out_path = '../data/pareto_analysis.json'
with open(out_path, 'w') as f:
    json.dump(results, f, indent=2)
print(f'\nSaved to {out_path}')
