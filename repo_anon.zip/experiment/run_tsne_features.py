"""
Sample-level t-SNE of learned features (leave-3000).

Trains vib_Z (1ch) and vibcur_6ch TinyCNN models with the standard protocol
(seed=42, EPOCHS=30, best-epoch selection), extracts 128-d penultimate features
(output of Linear(256->128), hooked at model.net[23]) for ALL target-domain test
samples at the best epoch, and embeds them with t-SNE.

Output: ../data/tsne_features.json
Plot:   scripts/fig7_tsne_features.py (run after this script)

Run from the experiment/ directory of the D-drive repo:
    cd experiment
    python run_tsne_features.py

Estimated runtime: ~15 min on GPU (two training runs) + ~2 min t-SNE.
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from copy import deepcopy
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN

EPOCHS = 30
SEED = 42
MODELS = {'vib_Z': [2], 'vibcur_6ch': [0, 1, 2, 3, 4, 5]}

sc = SCENARIOS['leave_3000']
X_src, y_src = load_domains(sc['source'])
X_tgt, y_tgt = load_domains(sc['target'])
print(f'Data: src={X_src.shape}, tgt={X_tgt.shape}', flush=True)

def train_and_extract(cfg_name, ch_idx):
    torch.manual_seed(SEED); np.random.seed(SEED)
    X_sc = select_channels(X_src, ch_idx)
    X_tc = select_channels(X_tgt, ch_idx)
    dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
    dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(), torch.from_numpy(y_tgt).long()), 512, shuffle=False, pin_memory=True)

    model = TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    best, best_state = 0.0, None
    t0 = time.time()
    for ep in range(EPOCHS):
        model.train()
        for xb, yb in dl_src:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
        sched.step()
        model.eval(); correct = 0
        with torch.no_grad():
            for xb, yb in dl_tgt:
                p = model(xb.to(DEVICE)).argmax(1)
                correct += p.eq(yb.to(DEVICE)).sum().item()
        acc = correct / len(dl_tgt.dataset)
        if acc > best:
            best, best_state = acc, deepcopy(model.state_dict())
        if (ep + 1) % 10 == 0:
            print(f'  {cfg_name} ep {ep+1}/{EPOCHS} acc={acc*100:.2f}% best={best*100:.2f}%', flush=True)
    print(f'  {cfg_name}: trained in {time.time()-t0:.0f}s, best={best*100:.2f}%', flush=True)

    # ---- feature extraction at best epoch ----
    model.load_state_dict(best_state)
    model.eval()
    feats = {}
    hook = model.net[23].register_forward_hook(lambda m, i, o: feats.__setitem__('out', o))
    F_list, P_list = [], []
    with torch.no_grad():
        for xb, yb in dl_tgt:
            logits = model(xb.to(DEVICE))
            F_list.append(feats['out'].cpu())
            P_list.append(logits.argmax(1).cpu())
    hook.remove()
    F = torch.cat(F_list).numpy()          # (N, 128)
    P = torch.cat(P_list).numpy()
    return best, F, P

# ---- t-SNE ----
from sklearn.manifold import TSNE

out = {'meta': {'scenario': 'leave_3000', 'seed': SEED, 'epochs': EPOCHS,
                'feature': 'penultimate Linear(256->128), best-epoch model',
                'tsne': {'perplexity': 30, 'init': 'pca', 'random_state': 42}},
       'labels': [MERGE_NAME[int(c)] for c in y_tgt],
       'label_ids': y_tgt.tolist(),
       'class_names': [MERGE_NAME[c] for c in range(NUM_CLASSES)]}

for cfg_name, ch_idx in MODELS.items():
    print(f'\n=== {cfg_name} ===', flush=True)
    best, F, P = train_and_extract(cfg_name, ch_idx)
    print(f'  Running t-SNE on {F.shape[0]} samples x {F.shape[1]} dims...', flush=True)
    t0 = time.time()
    emb = TSNE(n_components=2, perplexity=30, init='pca', learning_rate='auto',
               random_state=SEED).fit_transform(F)
    print(f'  t-SNE done in {time.time()-t0:.0f}s', flush=True)
    out[cfg_name] = {
        'best_acc': round(float(best) * 100, 2),
        'embedding': np.round(emb, 4).tolist(),
        'preds': P.tolist(),
    }

with open('../data/tsne_features.json', 'w') as f:
    json.dump(out, f)
print(f"\nSaved: ../data/tsne_features.json ({len(out['labels'])} samples, 2 models)", flush=True)
print('Next: python scripts\\fig7_tsne_features.py  (from repo root)', flush=True)
