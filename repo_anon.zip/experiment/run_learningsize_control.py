"""
Learning-curve / data-quantity control for the recording-disjoint analysis.

Question: the run-disjoint split (run_disjoint_multiseed.py) removes recording
overlap AND halves the source data, so its accuracy drop Delta mixes two
factors.  This control isolates the data-quantity factor: the standard
(leaky) domain-level split is kept fully intact --- all 90 recordings keep
their source-domain windows, so the overlap structure is 100% preserved ---
and only the source WINDOWS are randomly subsampled to 25% / 50% / 75%.

    Delta_leak  ~=  standard(50%) - disjoint

Note (added after the runs): the learning curve is not required to be
monotone --- 5 of 8 config x scenario curves are non-monotone within seed
variance --- so the comparison is descriptive, not a formal bound: if the
curve is flat (within seed variance) between 25% and 100%, reduced training
volume cannot explain the disjoint split's accuracy drop.  Where the curve
does slope (cur_ABC), the 50%-vs-100% difference estimates the volume
component directly.

Design details
--------------
- Nested subsets shared across configs and seeds: one permutation per
  scenario (RandomState(7)); the 25% subset is a prefix of the 50% subset,
  etc.  Identical data across seeds isolates training-seed variance.
- Windowing comes from the same NPZ caches as the main experiments
  (2048 samples, 50% overlap, per-window z-score).
- Training protocol identical to run_multi_seed.py: TinyCNN, AdamW
  (lr 5e-4, wd 1e-4), cosine annealing over 30 epochs, batch 256/512,
  plain cross-entropy, best-epoch on target, seeds 42/123/456.
- 100% reference values are already in data/multi_seed_results_full.json.

Output: ../data/learningsize_control_results.json (resumable).

Run from the experiment/ directory:
    C:\\Python314\\python.exe run_learningsize_control.py
(needs PyTorch + CUDA; ~1.5-2 h on an RTX 5070 Ti Laptop GPU)
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN

SEEDS = [42, 123, 456]
EPOCHS = 30
FRACTIONS = [0.25, 0.50, 0.75]
SCENARIO_LIST = ['leave_3000', 'leave_500']
CH_CONFIGS = {
    'vib_Z': [2], 'vib_XYZ': [0, 1, 2],
    'cur_ABC': [3, 4, 5], 'vibcur_6ch': [0, 1, 2, 3, 4, 5],
}
OUT = Path('../data/learningsize_control_results.json')

results = json.load(open(OUT)) if OUT.exists() else []
done = {(e['scenario'], e['config'], e['seed'], e['fraction']) for e in results}


def save():
    with open(OUT, 'w') as f:
        json.dump(results, f, indent=2)


t_start = time.time()
for sc_name in SCENARIO_LIST:
    sc = SCENARIOS[sc_name]
    print(f'\n{"=" * 60}\n{sc_name}: train {sc["source"]} -> test {sc["target"]}',
          flush=True)
    X_src, y_src = load_domains(sc['source'])
    X_tgt, y_tgt = load_domains(sc['target'])
    n_full = len(y_src)

    # nested subsets: one permutation, prefixes of increasing size
    perm = np.random.RandomState(7).permutation(n_full)
    frac_idx = {fr: np.sort(perm[:int(round(n_full * fr))]) for fr in FRACTIONS}
    print(f'  source windows: {n_full} -> ' +
          ', '.join(f'{fr:.0%}: {len(idx)}' for fr, idx in frac_idx.items()),
          flush=True)

    for fr in FRACTIONS:
        idx = frac_idx[fr]
        X_sub, y_sub = X_src[idx], y_src[idx]
        for cfg_name, ch_idx in CH_CONFIGS.items():
            X_sc = select_channels(X_sub, ch_idx)
            X_tc = select_channels(X_tgt, ch_idx)
            for seed in SEEDS:
                if (sc_name, cfg_name, seed, fr) in done:
                    continue
                t0 = time.time()
                torch.manual_seed(seed); np.random.seed(seed)
                dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(),
                                                  torch.from_numpy(y_sub).long()),
                                    256, shuffle=True, drop_last=True, pin_memory=True)
                dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(),
                                                  torch.from_numpy(y_tgt).long()),
                                    512, shuffle=False, pin_memory=True)
                model = TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES).to(DEVICE)
                opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
                sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
                best = 0.0
                for ep in range(EPOCHS):
                    model.train()
                    for xb, yb in dl_src:
                        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                        opt.zero_grad()
                        nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
                    sched.step()
                    model.eval(); correct = 0
                    with torch.no_grad():
                        for xb, yb in dl_tgt:
                            correct += model(xb.to(DEVICE)).argmax(1).eq(yb.to(DEVICE)).sum().item()
                    best = max(best, correct / len(dl_tgt.dataset))
                results.append({'scenario': sc_name, 'config': cfg_name, 'seed': seed,
                                'fraction': fr, 'best_acc': round(float(best) * 100, 2),
                                'n_src_windows': int(len(y_sub)),
                                'elapsed_s': round(time.time() - t0, 1)})
                save()
                print(f'  {fr:.0%} {cfg_name:12s} seed={seed}: {best * 100:.2f}% '
                      f'({time.time() - t0:.0f}s)', flush=True)
        del X_sub, y_sub

print(f'\nAll done in {(time.time() - t_start) / 60:.0f} min. Results: {OUT}', flush=True)

# ---------------- summary with 100% references ----------------
full = json.load(open('../data/multi_seed_results_full.json'))
print('\n=== Learning curve (mean +/- std over seeds; 100% = standard full split) ===',
      flush=True)
for sc_name in SCENARIO_LIST:
    for cfg_name in CH_CONFIGS:
        row = []
        for fr in FRACTIONS + [1.0]:
            if fr == 1.0:
                vals = [e['best_acc'] for e in full
                        if e['scenario'] == sc_name and e['config'] == cfg_name]
            else:
                vals = [e['best_acc'] for e in results
                        if e['scenario'] == sc_name and e['config'] == cfg_name
                        and e['fraction'] == fr]
            if vals:
                row.append(f'{np.mean(vals):6.2f}+/-{np.std(vals, ddof=1) if len(vals) > 1 else 0:4.2f}')
            else:
                row.append('     ---     ')
        print(f'  {sc_name:12s} {cfg_name:12s} 25%:{row[0]}  50%:{row[1]}  '
              f'75%:{row[2]}  100%:{row[3]}', flush=True)
