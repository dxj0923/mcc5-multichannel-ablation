"""
Extension: multi-seed runs for the four channel configurations NOT covered by
data/multi_seed_results.json (vib_XY, vib_XYZ, cur_ABC, vib_XYZ_curA),
4 scenarios x 3 seeds, using the identical protocol of run_multi_seed.py
(EPOCHS=30, best-epoch selection, AdamW 5e-4, batch 256/512).

RESUMABLE: after every run the result is appended to
../data/multi_seed_extension.json; re-running the script skips completed
(scenario, config, seed) triples. A ~4.5 h GPU job can be split across sessions.

At the end, merges with ../data/multi_seed_results.json into
../data/multi_seed_results_full.json and writes a Table-2-ready per-class
mean +/- std summary to ../data/per_class_multiseed_summary.json (leave_3000).

Run from the experiment/ directory of the D-drive repo:
    cd experiment
    python run_multiseed_extension.py
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN

SEEDS = [42, 123, 456]
SCENARIOS_LIST = ['leave_3000', 'leave_500', 'low_to_high', 'high_to_low']
CH_CONFIGS = {
    'vib_XY': [0, 1], 'vib_XYZ': [0, 1, 2],
    'cur_ABC': [3, 4, 5], 'vib_XYZ_curA': [0, 1, 2, 3],
}
EPOCHS = 30
OUT = Path('../data/multi_seed_extension.json')

# ---- resume: load already finished runs ----
done = []
if OUT.exists():
    done = json.load(open(OUT))
    print(f'Resuming: {len(done)} runs already completed', flush=True)
finished = {(r['scenario'], r['config'], r['seed']) for r in done}
results = list(done)

def save():
    with open(OUT, 'w') as f:
        json.dump(results, f, indent=2)

for sc_name in SCENARIOS_LIST:
    sc = SCENARIOS[sc_name]
    print(f'\n{"="*60}\n{sc_name}: train {sc["source"]} -> test {sc["target"]}', flush=True)
    X_src, y_src = load_domains(sc['source'])
    X_tgt, y_tgt = load_domains(sc['target'])

    for cfg_name, ch_idx in CH_CONFIGS.items():
        X_sc = select_channels(X_src, ch_idx)
        X_tc = select_channels(X_tgt, ch_idx)
        for seed in SEEDS:
            if (sc_name, cfg_name, seed) in finished:
                print(f'  {cfg_name:15s} seed={seed}: SKIP (done)', flush=True)
                continue
            t0 = time.time()
            torch.manual_seed(seed); np.random.seed(seed)
            dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
            dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(), torch.from_numpy(y_tgt).long()), 512, shuffle=False, pin_memory=True)
            model = TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES).to(DEVICE)
            opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
            sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
            best, best_preds, best_labels = 0.0, None, None
            for ep in range(EPOCHS):
                model.train()
                for xb, yb in dl_src:
                    xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                    opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
                sched.step()
                model.eval(); correct = 0; ap, al = [], []
                with torch.no_grad():
                    for xb, yb in dl_tgt:
                        p = model(xb.to(DEVICE)).argmax(1)
                        correct += p.eq(yb.to(DEVICE)).sum().item()
                        ap.append(p.cpu()); al.append(yb)
                acc = correct / len(dl_tgt.dataset)
                if acc > best: best = acc; best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
                if (ep + 1) % 10 == 0:
                    print(f'    ep {ep+1}/{EPOCHS} acc={acc*100:.2f}% best={best*100:.2f}%', flush=True)
            pc = {MERGE_NAME[c]: float((best_preds[best_labels == c] == c).mean()) for c in range(NUM_CLASSES) if (best_labels == c).sum() > 0}
            for c in range(NUM_CLASSES):
                if (best_labels == c).sum() == 0: pc[MERGE_NAME[c]] = 0.0
            elapsed = time.time() - t0
            results.append({'scenario': sc_name, 'config': cfg_name, 'seed': seed,
                'best_acc': round(float(best) * 100, 2),
                'per_class': {k: round(v * 100, 2) for k, v in pc.items()},
                'elapsed_s': round(elapsed, 1)})
            mac = np.mean(list(pc.values())) * 100
            print(f'  {cfg_name:15s} seed={seed}: {best*100:.2f}% macro={mac:.2f}% ({elapsed:.0f}s)', flush=True)
            save()  # incremental save -> resumable

# ---- merge with existing multi-seed results ----
base_path = Path('../data/multi_seed_results.json')
base = json.load(open(base_path)) if base_path.exists() else []
merged = base + results
with open('../data/multi_seed_results_full.json', 'w') as f:
    json.dump(merged, f, indent=2)
print(f'\nMerged: {len(base)} existing + {len(results)} extension = {len(merged)} runs', flush=True)

# ---- per-class mean +/- std summary (Table 2 upgrade, leave_3000) ----
summary = {}
for r in merged:
    if r['scenario'] != 'leave_3000':
        continue
    cfg = r['config']
    summary.setdefault(cfg, {}).setdefault('per_class', {})
    for cname, acc in r['per_class'].items():
        summary[cfg]['per_class'].setdefault(cname, []).append(acc)
    summary[cfg].setdefault('best_acc', []).append(r['best_acc'])

out = {}
for cfg, d in summary.items():
    out[cfg] = {
        'n_seeds': len(d['best_acc']),
        'best_acc_mean': round(float(np.mean(d['best_acc'])), 2),
        'best_acc_std': round(float(np.std(d['best_acc'], ddof=1)), 2) if len(d['best_acc']) > 1 else 0.0,
        'per_class': {
            c: {'mean': round(float(np.mean(v)), 2),
                'std': round(float(np.std(v, ddof=1)), 2) if len(v) > 1 else 0.0}
            for c, v in sorted(d['per_class'].items())
        },
    }
with open('../data/per_class_multiseed_summary.json', 'w') as f:
    json.dump(out, f, indent=2)

print('\n=== leave_3000 per-class mean +/- std (n=3) ===', flush=True)
for cfg, d in out.items():
    print(f"{cfg}: acc={d['best_acc_mean']}+/-{d['best_acc_std']}", flush=True)
    for c, v in d['per_class'].items():
        print(f"    {c:12s} {v['mean']:6.2f} +/- {v['std']:.2f}", flush=True)
print('\nSaved: ../data/multi_seed_results_full.json, ../data/per_class_multiseed_summary.json', flush=True)
