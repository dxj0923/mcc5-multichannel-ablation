"""
M1 (2026-08-30): leave_1000 direct test — is 1000 rpm above the diagnostic floor?
Protocol identical to run_multi_seed.py: TinyCNN, AdamW 5e-4 (wd 1e-4),
cosine annealing over 30 epochs, plain cross-entropy, batch 256,
best-epoch checkpoint on target domain, seeds 42/123/456.
Configs match Table 2 (tab:ablation) columns so leave_1000 can be added as a column.

Run locally (cmd):
    cd experiment
    python run_leave1000.py

Estimated runtime: 18 runs x ~5-6 min = 1.5-2 h on an RTX 5070 Ti Laptop GPU.
Output: ../data/leave1000_multiseed_results.json (+ per-class summary printed).
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME
from data import load_domains, select_channels
from models import TinyCNN

SEEDS = [42, 123, 456]
EPOCHS = 30
SCENARIO = {'source': [500, 1500, 2000, 2500, 3000], 'target': [1000]}
CH_CONFIGS = {
    'vib_Z': [2], 'vib_XY': [0, 1], 'vib_XYZ': [0, 1, 2],
    'cur_ABC': [3, 4, 5], 'vib_XYZ_curA': [0, 1, 2, 3], 'vibcur_6ch': [0, 1, 2, 3, 4, 5],
}

print(f'Device: {DEVICE}')
t_all = time.time()
X_src, y_src = load_domains(SCENARIO['source'])
X_tgt, y_tgt = load_domains(SCENARIO['target'])
print(f'leave_1000: src={X_src.shape} tgt={X_tgt.shape}')

results = []
for cfg_name, ch_idx in CH_CONFIGS.items():
    X_sc = select_channels(X_src, ch_idx)
    X_tc = select_channels(X_tgt, ch_idx)
    for seed in SEEDS:
        t0 = time.time()
        torch.manual_seed(seed); np.random.seed(seed)
        dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()),
                            256, shuffle=True, drop_last=True, pin_memory=True)
        dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(), torch.from_numpy(y_tgt).long()),
                            512, shuffle=False, pin_memory=True)
        model = TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES).to(DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        best, best_preds, best_labels = 0.0, None, None
        for ep in range(EPOCHS):
            model.train()
            for xb, yb in dl_src:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
            sched.step()
            model.eval(); correct = 0; ap, al = [], []
            with torch.no_grad():
                for xb, yb in dl_tgt:
                    p = model(xb.to(DEVICE)).argmax(1)
                    correct += p.eq(yb.to(DEVICE)).sum().item()
                    ap.append(p.cpu()); al.append(yb)
            acc = correct / len(dl_tgt.dataset)
            if acc > best:
                best = acc; best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
            if (ep + 1) % 10 == 0:
                print(f'    {cfg_name} seed={seed} epoch {ep+1}/{EPOCHS}: target acc={acc*100:.2f}% (best {best*100:.2f}%)', flush=True)
        pc = {}
        for c in range(NUM_CLASSES):
            mask = best_labels == c
            pc[MERGE_NAME[c]] = float((best_preds[mask] == c).mean()) if mask.sum() > 0 else 0.0
        elapsed = time.time() - t0
        results.append({'scenario': 'leave_1000', 'config': cfg_name, 'seed': seed,
                        'best_acc': round(float(best) * 100, 2),
                        'per_class': {k: round(v * 100, 2) for k, v in pc.items()},
                        'elapsed_s': round(elapsed, 1)})
        mac = np.mean(list(pc.values())) * 100
        print(f'  {cfg_name:12s} seed={seed:3d}: overall={best*100:.2f}% macro={mac:.2f}% ({elapsed:.0f}s)', flush=True)

with open('../data/leave1000_multiseed_results.json', 'w') as f:
    json.dump(results, f, indent=2)

print(f'\n{"="*60}\n=== leave_1000 summary (mean +/- std, n={len(SEEDS)}) ===')
for cfg_name in CH_CONFIGS:
    runs = [r for r in results if r['config'] == cfg_name]
    accs = [r['best_acc'] for r in runs]
    print(f'{cfg_name:12s}: overall={np.mean(accs):.2f}+/-{np.std(accs):.2f}  {accs}')
    for cls in MERGE_NAME.values():
        v = [r['per_class'][cls] for r in runs]
        print(f'    {cls:12s} {np.mean(v):6.2f} +/- {np.std(v):.2f}')

print(f'\nTotal elapsed: {(time.time()-t_all)/60:.1f} min')
print('Saved: ../data/leave1000_multiseed_results.json')
