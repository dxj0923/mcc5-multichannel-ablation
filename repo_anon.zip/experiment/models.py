"""Model architectures."""
import torch
import torch.nn as nn

class TinyCNN(nn.Module):
    """Lightweight 5-block CNN used for channel ablation.
    in_c = number of input channels (1 for vib_Z, 6 for full fusion).
    """
    def __init__(self, in_c=1, n_cls=10):
        super().__init__()
        self.net = nn.Sequential(
            nn.Conv1d(in_c, 32, 15, padding=7, bias=False),
            nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 11, padding=5, bias=False),
            nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 9, padding=4, bias=False),
            nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128, 256, 7, padding=3, bias=False),
            nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(256, 256, 5, padding=2, bias=False),
            nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(),
            nn.Dropout(0.3),
            nn.Linear(256, 128), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(128, n_cls),
        )
    def forward(self, x):
        return self.net(x)

class DualBranchCNN(nn.Module):
    """Separate vib/cur streams fused at feature level."""
    def __init__(self, n_cls=10):
        super().__init__()
        self.vib_net = nn.Sequential(
            nn.Conv1d(3, 32, 15, padding=7, bias=False), nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 11, padding=5, bias=False), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 9, padding=4, bias=False), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128, 256, 7, padding=3, bias=False), nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(256, 256, 5, padding=2, bias=False), nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Dropout(0.3),
        )
        self.cur_net = nn.Sequential(
            nn.Conv1d(3, 32, 15, padding=7, bias=False), nn.BatchNorm1d(32), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(32, 64, 11, padding=5, bias=False), nn.BatchNorm1d(64), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(64, 128, 9, padding=4, bias=False), nn.BatchNorm1d(128), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(128, 256, 7, padding=3, bias=False), nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.Conv1d(256, 256, 5, padding=2, bias=False), nn.BatchNorm1d(256), nn.ReLU(), nn.MaxPool1d(2),
            nn.AdaptiveAvgPool1d(1), nn.Flatten(), nn.Dropout(0.3),
        )
        self.fc = nn.Sequential(
            nn.Linear(512, 256), nn.ReLU(), nn.Dropout(0.3),
            nn.Linear(256, n_cls),
        )
    def forward(self, x):
        # x: (B, 6, 2048) — first 3 = vib, last 3 = cur
        vib = x[:, :3, :]
        cur = x[:, 3:, :]
        f_v = self.vib_net(vib)
        f_c = self.cur_net(cur)
        return self.fc(torch.cat([f_v, f_c], dim=1))
