"""
Unified configuration for MCC5-THU Motor dataset experiments.
All paths resolve from environment variable MCC5_ROOT (fallback: ./raw_data).
"""
import os, torch
from pathlib import Path

_ROOT = os.environ.get('MCC5_ROOT')
if _ROOT is None:
    _ROOT = os.environ.get('MCC5_ROOT', './raw_data')
DATA_ROOT = Path(_ROOT)

CACHE_MULTI = DATA_ROOT / 'cached_multichannel'
CACHE_SINGLE = DATA_ROOT / 'cached_dataset'
RESULTS_DIR = DATA_ROOT / 'results'
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

DEVICE = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

# 10-class merge mapping (14 original → 10 merged)
LABEL_MERGE = {0:0,1:1,2:1,3:2,4:2,5:3,6:4,7:4,8:5,9:5,10:6,11:7,12:8,13:9}
NUM_CLASSES = 10
MERGE_NAME = {0:'health', 1:'inner', 2:'outer', 3:'ball', 4:'winding',
              5:'static_ec', 6:'dynamic', 7:'broken_bar', 8:'voltage', 9:'bend'}
ALL_DOMAINS = [500, 1000, 1500, 2000, 2500, 3000]

SCENARIOS = {
    'leave_3000':    {'source': [500, 1000, 1500, 2000, 2500], 'target': [3000]},
    'leave_500':     {'source': [1000, 1500, 2000, 2500, 3000], 'target': [500]},
    'low_to_high':   {'source': [500, 1000, 1500], 'target': [2000, 2500, 3000]},
    'high_to_low':   {'source': [2000, 2500, 3000], 'target': [500, 1000, 1500]},
}
