"""
Add two extra seeds (789, 1011) to the main multi-seed campaign, taking every
Table-2 cell from n=3 to n=5 seeds (reviewer-requested power increase;
leave_500/vib_XYZ had a seed std of 8.4 pp at n=3).

Protocol is IDENTICAL to run_multi_seed.py / run_fill_gaps_multiseed.py
(30 epochs, best-epoch checkpoint, same model/optimizer/batch sizes), so the
new entries are directly comparable with the existing 84.

Execution order puts the reviewer-critical cells first:
    leave_500 x {vib_Z, vib_XYZ, cur_ABC, vibcur_6ch}  (8 runs, ~1.5 h)
then the remaining 48 runs for full n=5 coverage (~7 h more).
The script is resumable: finished runs are skipped on restart, and you can
stop after the leave_500 block (Ctrl+C) without losing anything.

Run from the experiment/ directory:
    C:\\Python314\\python.exe run_extra_seeds.py
(needs PyTorch + CUDA)
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN, DualBranchCNN

SEEDS = [789, 1011]          # the two NEW seeds (42/123/456 already done)
EPOCHS = 30
OUT = Path('../data/multi_seed_results_full.json')

CH_CONFIGS = {
    'vib_Z': [2], 'vib_XY': [0, 1], 'vib_XYZ': [0, 1, 2],
    'cur_ABC': [3, 4, 5], 'vib_XYZ_curA': [0, 1, 2, 3], 'vibcur_6ch': [0, 1, 2, 3, 4, 5],
}

# priority block first (reviewer-critical), then the rest for full n=5
PRIORITY = ['leave_500']
PRIORITY_CFGS = ['vib_Z', 'vib_XYZ', 'cur_ABC', 'vibcur_6ch']
CELLS = ([(sc, cfg) for sc in PRIORITY for cfg in PRIORITY_CFGS] +
         [(sc, cfg) for sc in SCENARIOS for cfg in list(CH_CONFIGS) + ['dual_branch']
          if not (sc in PRIORITY and cfg in PRIORITY_CFGS)])

results = json.load(open(OUT)) if OUT.exists() else []
done = {(e['scenario'], e['config'], e['seed']) for e in results}
planned = sum(1 for s, c in CELLS for sd in SEEDS if (s, c, sd) not in done)
print(f'Existing entries: {len(results)}; {planned} runs planned (2 new seeds x {len(CELLS)} cells)',
      flush=True)


def save():
    with open(OUT, 'w') as f:
        json.dump(results, f, indent=2)


def run_cell(sc_name, cfg_name):
    ch_idx = CH_CONFIGS.get(cfg_name)
    sc = SCENARIOS[sc_name]
    X_src, y_src = load_domains(sc['source'])
    X_tgt, y_tgt = load_domains(sc['target'])
    X_sc = select_channels(X_src, ch_idx) if ch_idx else X_src
    X_tc = select_channels(X_tgt, ch_idx) if ch_idx else X_tgt
    for seed in SEEDS:
        if (sc_name, cfg_name, seed) in done:
            print(f'  skip {sc_name}/{cfg_name}/seed={seed} (done)', flush=True)
            continue
        t0 = time.time()
        torch.manual_seed(seed); np.random.seed(seed)
        dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(),
                                          torch.from_numpy(y_src).long()),
                            256, shuffle=True, drop_last=True, pin_memory=True)
        dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(),
                                          torch.from_numpy(y_tgt).long()),
                            512, shuffle=False, pin_memory=True)
        model = (DualBranchCNN(n_cls=NUM_CLASSES) if cfg_name == 'dual_branch'
                 else TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES)).to(DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        best, best_preds, best_labels = 0.0, None, None
        for ep in range(EPOCHS):
            model.train()
            for xb, yb in dl_src:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
            sched.step()
            model.eval(); correct = 0; ap, al = [], []
            with torch.no_grad():
                for xb, yb in dl_tgt:
                    p = model(xb.to(DEVICE)).argmax(1)
                    correct += p.eq(yb.to(DEVICE)).sum().item()
                    ap.append(p.cpu()); al.append(yb)
            acc = correct / len(dl_tgt.dataset)
            if acc > best:
                best = acc
                best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
        pc = {}
        for c in range(NUM_CLASSES):
            mask = best_labels == c
            pc[MERGE_NAME[c]] = float((best_preds[mask] == c).mean()) if mask.sum() > 0 else 0.0
        elapsed = time.time() - t0
        results.append({'scenario': sc_name, 'config': cfg_name, 'seed': seed,
                        'best_acc': round(float(best) * 100, 2),
                        'per_class': {k: round(v * 100, 2) for k, v in pc.items()},
                        'elapsed_s': round(elapsed, 1)})
        save()  # incremental save -> resumable
        print(f'  {sc_name:12s} {cfg_name:12s} seed={seed}: {best * 100:.2f}% ({elapsed:.0f}s)',
              flush=True)


t_start = time.time()
for sc_name, cfg_name in CELLS:
    print(f'\n--- {sc_name} / {cfg_name} ---', flush=True)
    run_cell(sc_name, cfg_name)

print(f'\nTotal entries now: {len(results)} -> {OUT}', flush=True)
print(f'Elapsed: {(time.time() - t_start) / 3600:.1f} h', flush=True)

# per-cell summary over ALL seeds (old 3 + new 2) for the touched campaign
print('\n=== n=5 summary (mean +/- std over all seeds) ===', flush=True)
for sc_name, cfg_name in CELLS:
    vals = [e['best_acc'] for e in results
            if e['scenario'] == sc_name and e['config'] == cfg_name]
    if len(vals) >= 2:
        print(f'  {sc_name:12s} {cfg_name:12s} n={len(vals)}: '
              f'{np.mean(vals):.2f} +/- {np.std(vals, ddof=1):.2f}', flush=True)
print('\nNext: tell the assistant the run is finished — tables/figures/audits '
      'must be regenerated for n=5.', flush=True)
