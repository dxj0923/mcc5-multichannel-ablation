"""
Fill the remaining Table-2 cells so that EVERY reported cell uses the
standard protocol (3 seeds x 30 epochs, best-epoch checkpoint).

Status (2026-10-12): COMPLETE.  All 84 entries (28 cells x 3 seeds) are now
raw 30-epoch runs in data/multi_seed_results_full.json; the 20-epoch summary
file (multi_seed_summary.json) is deprecated and no longer read by any
figure script.  This script is kept for provenance and is fully resumable:
re-running it is a no-op since all cells already exist.

Historical background
---------------------
data/multi_seed_results_full.json originally covered 20 of the 28
scenario x config cells.  The remaining cells came from an earlier 20-epoch
campaign as summary statistics only:

    (low_to_high, vib_Z)        67.46 +/- 0.58   <- 20 epochs
    (high_to_low, vib_Z)        64.75 +/- 5.55   <- 20 epochs
    (low_to_high, vibcur_6ch)   88.23 +/- 3.28   <- 20 epochs
    (high_to_low, vibcur_6ch)   79.63 +/- 3.20   <- 20 epochs
    (low_to_high, dual_branch)  87.74 +/- 1.49   <- 20 epochs
    (high_to_low, dual_branch)  82.40 +/- 1.48   <- 20 epochs

and one single-run cell:

    (leave_500,   vib_Z)        61.5 (former dagger in Table 2 / Fig. 2)
    (leave_500,   dual_branch)  not yet measured

This script re-ran exactly these 8 cells (x 3 seeds = 24 runs) with the
standard 30-epoch protocol of run_multi_seed.py and appended the raw
per-seed entries to ../data/multi_seed_results_full.json.

Run from the experiment/ directory:
    C:\\Python314\\python.exe run_fill_gaps_multiseed.py
(needs PyTorch + CUDA)
"""
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN, DualBranchCNN

SEEDS = [42, 123, 456]
EPOCHS = 30
OUT = Path('../data/multi_seed_results_full.json')

# (scenario, config, channels) — the 8 cells missing raw 30-epoch runs
CELLS = [
    ('low_to_high', 'vib_Z',       [2]),
    ('high_to_low', 'vib_Z',       [2]),
    ('leave_500',   'vib_Z',       [2]),
    ('low_to_high', 'vibcur_6ch',  [0, 1, 2, 3, 4, 5]),
    ('high_to_low', 'vibcur_6ch',  [0, 1, 2, 3, 4, 5]),
    ('low_to_high', 'dual_branch', [0, 1, 2, 3, 4, 5]),
    ('high_to_low', 'dual_branch', [0, 1, 2, 3, 4, 5]),
    ('leave_500',   'dual_branch', [0, 1, 2, 3, 4, 5]),
]

results = json.load(open(OUT)) if OUT.exists() else []
done = {(e['scenario'], e['config'], e['seed']) for e in results}
print(f'Existing entries: {len(results)}; {len(CELLS) * len(SEEDS)} runs planned, '
      f'{sum((s, c, sd) in done for s, c, _ in CELLS for sd in SEEDS)} already done',
      flush=True)


def save():
    with open(OUT, 'w') as f:
        json.dump(results, f, indent=2)


def run_cell(sc_name, cfg_name, ch_idx):
    sc = SCENARIOS[sc_name]
    X_src, y_src = load_domains(sc['source'])
    X_tgt, y_tgt = load_domains(sc['target'])
    X_sc = select_channels(X_src, ch_idx)
    X_tc = select_channels(X_tgt, ch_idx)
    for seed in SEEDS:
        if (sc_name, cfg_name, seed) in done:
            print(f'  skip {sc_name}/{cfg_name}/seed={seed} (done)', flush=True)
            continue
        t0 = time.time()
        torch.manual_seed(seed); np.random.seed(seed)
        dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(),
                                          torch.from_numpy(y_src).long()),
                            256, shuffle=True, drop_last=True, pin_memory=True)
        dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(),
                                          torch.from_numpy(y_tgt).long()),
                            512, shuffle=False, pin_memory=True)
        model = (DualBranchCNN(n_cls=NUM_CLASSES) if cfg_name == 'dual_branch'
                 else TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES)).to(DEVICE)
        opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
        sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
        best, best_preds, best_labels = 0.0, None, None
        for ep in range(EPOCHS):
            model.train()
            for xb, yb in dl_src:
                xb, yb = xb.to(DEVICE), yb.to(DEVICE)
                opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
            sched.step()
            model.eval(); correct = 0; ap, al = [], []
            with torch.no_grad():
                for xb, yb in dl_tgt:
                    p = model(xb.to(DEVICE)).argmax(1)
                    correct += p.eq(yb.to(DEVICE)).sum().item()
                    ap.append(p.cpu()); al.append(yb)
            acc = correct / len(dl_tgt.dataset)
            if acc > best:
                best = acc
                best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
        pc = {}
        for c in range(NUM_CLASSES):
            mask = best_labels == c
            pc[MERGE_NAME[c]] = float((best_preds[mask] == c).mean()) if mask.sum() > 0 else 0.0
        elapsed = time.time() - t0
        results.append({'scenario': sc_name, 'config': cfg_name, 'seed': seed,
                        'best_acc': round(float(best) * 100, 2),
                        'per_class': {k: round(v * 100, 2) for k, v in pc.items()},
                        'elapsed_s': round(elapsed, 1)})
        save()  # incremental save -> resumable
        print(f'  {sc_name:12s} {cfg_name:12s} seed={seed}: {best * 100:.2f}% ({elapsed:.0f}s)',
              flush=True)


for sc_name, cfg_name, ch_idx in CELLS:
    print(f'\n--- {sc_name} / {cfg_name} ---', flush=True)
    run_cell(sc_name, cfg_name, ch_idx)

print(f'\nTotal entries now: {len(results)} -> {OUT}', flush=True)
print('Next: regenerate Fig. 2 with scripts/fig2_ablation.py and update Table 2.',
      flush=True)
