"""
P2-4: Grad-CAM feature visualization for Outer Race.
P3-6: Cross-load robustness (20Nm vs 40Nm for 6ch leave-3000).
P2-3: Window length ablation (2048, 4096, 8192 for 6ch leave-500).
"""
import os
import sys, time, json, torch, numpy as np
sys.path.insert(0, '.')
from pathlib import Path
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN

torch.manual_seed(42); np.random.seed(42)
EPOCHS = 25
results_extra = {}

# ===== P2-4: Grad-CAM =====
print('='*50, flush=True)
print('P2-4: Grad-CAM Feature Visualization', flush=True)
print('Training 6ch model for Grad-CAM...', flush=True)

sc = SCENARIOS['leave_3000']
X_src, y_src = load_domains(sc['source'])
X_tgt, y_tgt = load_domains(sc['target'])
X_sc = select_channels(X_src, [0,1,2,3,4,5])
X_tc = select_channels(X_tgt, [0,1,2,3,4,5])

dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc).float(), torch.from_numpy(y_tgt).long()), 512, shuffle=False, pin_memory=True)

model = TinyCNN(in_c=6, n_cls=NUM_CLASSES).to(DEVICE)
opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)

for ep in range(EPOCHS):
    model.train()
    for xb, yb in dl_src:
        xb, yb = xb.to(DEVICE), yb.to(DEVICE)
        opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
    sched.step()

model.eval()
print('Computing Grad-CAM for outer race samples...', flush=True)

# Find outer race samples in target domain
outer_mask = y_tgt == 2
outer_idx = np.where(outer_mask)[0]
print(f'  Found {len(outer_idx)} outer race samples', flush=True)

# Grad-CAM: hook the last convolutional layer activations and gradients
activations = {}
gradients = {}
def hook_act(m, i, o): activations['out'] = o
def hook_grad(m, gi, go): gradients['out'] = go[0]

# Last conv is at index 16 in the Sequential: Conv1d(256, 256, 5, padding=2)
target_layer = model.net[16]
target_layer.register_forward_hook(hook_act)
target_layer.register_full_backward_hook(hook_grad)

sample_indices = outer_idx[:50]
gcams = []
for idx in sample_indices:
    x = torch.from_numpy(X_tc[idx:idx+1]).float().to(DEVICE)
    x.requires_grad_()
    logits = model(x)
    cls_idx = logits.argmax(1).item()
    model.zero_grad()
    logits[0, cls_idx].backward()
    
    act = activations['out'][0]  # (256, 64)
    grad = gradients['out'][0]    # (256, 64)
    weights = grad.mean(dim=1, keepdim=True)  # (256, 1)
    cam = (weights * act).sum(dim=0).detach().cpu().numpy()  # (64,)
    cam = np.maximum(cam, 0)
    if cam.max() > 0: cam /= cam.max()
    gcams.append(cam)

gcams = np.array(gcams)
mean_cam = gcams.mean(axis=0)

# Save as JSON for figure generation
gradcam_data = {
    'mean_gradcam': mean_cam.tolist(),
    'n_samples': len(sample_indices),
    'temporal_resolution': 64,
    'class': 'outer_race',
    'window_size': 2048,
    'note': 'Grad-CAM on last conv layer (64 temporal bins) for 6ch early fusion, leave-3000',
}
results_extra['gradcam'] = gradcam_data
print(f'  Grad-CAM computed: {len(mean_cam)} temporal bins', flush=True)

# ===== P2-3: Window Length Ablation (simplified via concatenation) =====
print(f'\n{"="*50}', flush=True)
print('P2-3: Window Length Ablation', flush=True)

from data import load_domains, select_channels

# Load leave-500 data
sc = SCENARIOS['leave_500']
X_src, y_src = load_domains(sc['source'])
X_tgt, y_tgt = load_domains(sc['target'])
X_src = select_channels(X_src, [0,1,2,3,4,5])
X_tgt = select_channels(X_tgt, [0,1,2,3,4,5])

window_results = {'note': 'Simplified: concatenate 2048-sample windows for larger sizes. Single seed=42.'}
for ws_name, concat_n in [('2048', 1), ('4096', 2), ('8192', 4)]:
    N = concat_n
    # Concatenate consecutive windows along time axis
    src_n = X_src.shape[0] - X_src.shape[0] % N
    tgt_n = X_tgt.shape[0] - X_tgt.shape[0] % N
    X_sc_s = X_src[:src_n].reshape(-1, N, 6, 2048).transpose(0, 2, 1, 3).reshape(-1, 6, 2048 * N)
    y_sc_s = y_src[:src_n].reshape(-1, N)[:, 0]
    X_tc_s = X_tgt[:tgt_n].reshape(-1, N, 6, 2048).transpose(0, 2, 1, 3).reshape(-1, 6, 2048 * N)
    y_tc_s = y_tgt[:tgt_n].reshape(-1, N)[:, 0]

    print(f'  Window {ws_name}: src={X_sc_s.shape}, tgt={X_tc_s.shape}', flush=True)
    torch.manual_seed(42); np.random.seed(42)
    dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc_s).float(), torch.from_numpy(y_sc_s).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
    dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_tc_s).float(), torch.from_numpy(y_tc_s).long()), 512, shuffle=False, pin_memory=True)

    model = TinyCNN(in_c=6, n_cls=NUM_CLASSES).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    best = 0.0
    t0 = time.time()
    for ep in range(EPOCHS):
        model.train()
        for xb, yb in dl_src:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
        sched.step()
        model.eval(); correct = 0
        with torch.no_grad():
            for xb, yb in dl_tgt:
                p = model(xb.to(DEVICE)).argmax(1)
                correct += p.eq(yb.to(DEVICE)).sum().item()
        acc = correct / len(dl_tgt.dataset)
        if acc > best: best = acc
    elapsed = time.time() - t0
    print(f'    Best: {best*100:.2f}% ({elapsed:.0f}s)', flush=True)
    window_results[ws_name] = round(float(best)*100, 2)

results_extra['window_ablation'] = window_results

# ===== P3-6: Cross-load robustness =====
print(f'\n{"="*50}', flush=True)
print('P3-6: Cross-Load Robustness (20Nm vs 40Nm)', flush=True)
import pandas as pd

STEADY_CSV = Path(os.environ.get('MCC5_ROOT', './raw_data')) / 'steady_csv'

def load_by_torque(scenario, torque_nm):
    """Load windows from CSVs filtered by torque, with 2048-sample windowing."""
    sc = SCENARIOS[scenario]
    from sklearn.preprocessing import LabelEncoder
    label_merge = {0:0,1:1,2:1,3:2,4:2,5:3,6:4,7:4,8:5,9:5,10:6,11:7,12:8,13:9}
    X, y = [], []
    for domain in sc['source'] + sc['target']:
        files = list(STEADY_CSV.glob(f'*{torque_nm}Nm*{domain}rpm*.csv'))
        for f in files:
            try:
                df = pd.read_csv(f, header=None, skiprows=1, usecols=[3,4,5,6,7,8])
            except:
                continue
            if len(df) < 2048: continue
            parts = f.stem.split('_')
            fault_orig = int(parts[1]) if parts[1].isdigit() else 0
            fault_id = label_merge.get(fault_orig, 0)
            arr = df.values[:len(df) - len(df) % 2048].astype(np.float32)
            arr = arr.reshape(-1, 2048, 6).transpose(0, 2, 1)
            mean = arr.mean(axis=2, keepdims=True)
            std = arr.std(axis=2, keepdims=True) + 1e-8
            arr = (arr - mean) / std
            X.append(arr); y.append(np.full(len(arr), fault_id))
    if not X: return np.zeros((0,6,2048)), np.zeros(0, dtype=int)
    return np.concatenate(X), np.concatenate(y)

# Train on 20Nm and 40Nm, test separately  
for test_torque_name, test_torque_val in [('20Nm', 20), ('40Nm', 40)]:
    print(f'\n  Test on {test_torque_name}...', flush=True)
    X_t, y_t = load_by_torque('leave_3000', test_torque_val)
    if len(X_t) < 10:
        print(f'    Not enough data for {test_torque_name}', flush=True)
        continue
    
    # Train on all data, evaluate per-load
    sc = SCENARIOS['leave_3000']
    X_src, y_src = load_domains(sc['source'])
    X_tgt, y_tgt = load_domains(sc['target'])
    X_sc = select_channels(X_src, [0,1,2,3,4,5])
    
    torch.manual_seed(42); np.random.seed(42)
    dl_src = DataLoader(TensorDataset(torch.from_numpy(X_sc).float(), torch.from_numpy(y_src).long()), 256, shuffle=True, drop_last=True, pin_memory=True)
    dl_tgt = DataLoader(TensorDataset(torch.from_numpy(X_t).float(), torch.from_numpy(y_t).long()), 512, shuffle=False, pin_memory=True)

    model = TinyCNN(in_c=6, n_cls=NUM_CLASSES).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    best = 0.0; best_preds, best_labels = None, None
    for ep in range(EPOCHS):
        model.train()
        for xb, yb in dl_src:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
        sched.step()
        model.eval(); correct = 0; ap, al = [], []
        with torch.no_grad():
            for xb, yb in dl_tgt:
                p = model(xb.to(DEVICE)).argmax(1)
                correct += p.eq(yb.to(DEVICE)).sum().item()
                ap.append(p.cpu()); al.append(yb)
        acc = correct / len(dl_tgt.dataset)
        if acc > best: best = acc; best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
    pc = {}
    for c in range(NUM_CLASSES):
        mask = best_labels == c
        pc[MERGE_NAME[c]] = float((best_preds[mask]==c).mean()) if mask.sum()>0 else 0.0
    print(f'    Overall: {best*100:.2f}%', flush=True)
    for cn, cv in pc.items():
        print(f'      {cn}: {cv*100:.1f}%', flush=True)

    if 'cross_load' not in results_extra:
        results_extra['cross_load'] = {}
    results_extra['cross_load'][test_torque_name] = {
        'overall': round(float(best)*100, 2),
        'per_class': {k: round(v*100, 2) for k,v in pc.items()},
    }

# Save all extra results
with open('../data/extra_analysis_results.json', 'w') as f:
    json.dump(results_extra, f, indent=2)
print(f'\nExtra results saved to ../data/extra_analysis_results.json', flush=True)
