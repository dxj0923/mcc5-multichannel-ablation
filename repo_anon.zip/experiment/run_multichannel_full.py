"""
Full multi-scenario 6-channel fusion experiment across all 4 scenarios.
Saves overall accuracy, per-class accuracy, and confusion data.
"""
import time, json, os, sys
from datetime import datetime
from collections import Counter

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DEVICE, NUM_CLASSES, SCENARIOS, MERGE_NAME
from data import load_domains, select_channels
from models import TinyCNN

def train_full(X_src, y_src, X_tgt, y_tgt, epochs=30, seed=42):
    """Train TinyCNN on 6-channel data; return best_acc, per_class, confusion."""
    torch.manual_seed(seed)
    np.random.seed(seed)

    ds_src = TensorDataset(torch.from_numpy(X_src).float(), torch.from_numpy(y_src).long())
    ds_tgt = TensorDataset(torch.from_numpy(X_tgt).float(), torch.from_numpy(y_tgt).long())
    src_loader = DataLoader(ds_src, 256, shuffle=True, drop_last=True, pin_memory=True)
    tgt_loader = DataLoader(ds_tgt, 512, shuffle=False, pin_memory=True)

    model = TinyCNN(in_c=6, n_cls=NUM_CLASSES).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    crit = nn.CrossEntropyLoss()
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    best_acc = 0.0
    best_state = None
    best_preds, best_labels = None, None

    for ep in range(epochs):
        model.train()
        for xb, yb in src_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            crit(model(xb), yb).backward()
            opt.step()
        sched.step()

        model.eval()
        correct = 0
        ap, al = [], []
        with torch.no_grad():
            for xb, yb in tgt_loader:
                logits = model(xb.to(DEVICE))
                preds = logits.argmax(1)
                correct += preds.eq(yb.to(DEVICE)).sum().item()
                ap.append(preds.cpu())
                al.append(yb)
        acc = correct / len(y_tgt)
        if acc > best_acc:
            best_acc = acc
            best_preds = torch.cat(ap).numpy()
            best_labels = torch.cat(al).numpy()

    # Per-class accuracy
    per_class = {}
    for c in range(NUM_CLASSES):
        mask = best_labels == c
        per_class[MERGE_NAME[c]] = float((best_preds[mask] == c).mean()) if mask.sum() > 0 else 0.0

    # Confusion matrix (as dict of {true_class: {pred_class: count}})
    confusions = {}
    for c in range(NUM_CLASSES):
        mask = best_labels == c
        if mask.sum() > 0:
            counts = Counter(best_preds[mask])
            confusions[MERGE_NAME[c]] = {MERGE_NAME[int(k)]: int(v) for k, v in counts.items()}

    return float(best_acc), per_class, confusions

if __name__ == '__main__':
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    results = {}

    for sname, spec in SCENARIOS.items():
        src = spec['source']
        tgt = spec['target']
        print(f"\nScenario: {sname}  |  Source: {src}  Target: {tgt}")

        X_src, y_src = load_domains(src)
        X_tgt, y_tgt = load_domains(tgt)
        X_sc = select_channels(X_src, [0, 1, 2, 3, 4, 5])
        X_tc = select_channels(X_tgt, [0, 1, 2, 3, 4, 5])

        t0 = time.time()
        acc, pc, conf = train_full(X_sc, y_src, X_tc, y_tgt, seed=42)
        elapsed = time.time() - t0

        print(f"  acc={acc*100:.2f}%  ({elapsed:.0f}s)")
        results[sname] = {
            'best_acc': acc,
            'per_class': pc,
            'confusions': conf,
            'seed': 42,
            'elapsed_s': round(elapsed, 1),
            'timestamp': timestamp,
        }

    results['_meta'] = {'timestamp': timestamp, 'model': 'TinyCNN_6ch'}

    out_path = os.path.join(os.path.dirname(__file__), f'results_full_{timestamp}.json')
    with open(out_path, 'w') as f:
        json.dump(results, f, indent=2)
    print(f"\nResults saved to: {out_path}")
