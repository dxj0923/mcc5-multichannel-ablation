"""
Q4 follow-up: run-disjoint (recording-level) domain generalization,
with support for MULTIPLE disjoint partitions (split seeds).

Motivation
----------
Each 90 s MCC5-THU speed-circulation recording contains several speed
plateaus.  Steady-state extraction therefore assigns segments of the SAME
recording to different speed domains, and the standard scenario split
(source vs. target domains) can place windows from one recording in BOTH
the training and the test set (the dataset guide, Sec. 8.2, recommends
splitting at the recording level first).  This script quantifies how much
of the reported cross-speed accuracy survives a strict recording-disjoint
split.

Because any single A/B partition of the recordings is arbitrary, the
script can repeat the experiment with several independent random
partitions (split seeds 1, 2, ...), so that a result can be reported as
"mean +/- std across partitions", separating the effect of the disjoint
constraint from the luck of one particular partition.

Design
------
1. Scan the steady-state CSVs; the recording id is the filename stem
   before '_D_speed_'.
2. Stratified split of recordings into group A / B: fine strata are
   (merged class, torque, circulation top speed).
   - split seed 0 (default, keeps backward compatibility with the
     results already in the JSON): deterministic assignment, alternating
     within each stratum with a per-stratum phase rotation.
   - split seed > 0: np.random.RandomState(split_seed) shuffles the
     recordings inside every stratum and draws a random starting phase
     per stratum, then assigns alternately A/B/A/B.  The random phase is
     essential: most strata hold a single recording, so without it every
     such recording would always land in group A (severely unbalanced
     61/29 instead of ~45/45).
3. For each scenario, direction A->B trains on source-domain segments of
   group-A recordings and tests on target-domain segments of group-B
   recordings (and vice versa for B->A).  No recording contributes
   windows to both sides (asserted at runtime).  Because a target domain
   may be carried by only one recording per class x load, a single
   direction can lack some target classes (a warning is printed; this is
   expected for random partitions); the two directions are therefore
   also reported POOLED (every recording is tested exactly once, in the
   direction where it sits on the target side, so pooled always covers
   all 10 classes).
4. Windowing is identical to the main protocol: 2048-sample windows,
   50% overlap (stride 1024), per-window per-channel z-score, the six
   signal columns 3..8 (vib_XYZ, cur_ABC), composite-fault files skipped.
5. Training is identical to run_multi_seed.py: TinyCNN, AdamW
   (lr 5e-4, wd 1e-4), cosine annealing over 30 epochs, batch 256/512,
   plain cross-entropy, best-epoch checkpoint on the target domain,
   seeds 42/123/456.

The script first prints a leakage audit: for every scenario, how many
recordings appear on BOTH sides under the standard (non-disjoint) split.

Output: ../data/run_disjoint_multiseed_results.json (resumable; each
entry carries a 'split' field, older entries without it count as split 0).

Usage (from the experiment/ directory; needs PyTorch + CUDA):
    C:\\Python314\\python.exe run_disjoint_multiseed.py            # split 0, all 4 configs
    C:\\Python314\\python.exe run_disjoint_multiseed.py 1          # random partition 1, vibcur_6ch + cur_ABC
    C:\\Python314\\python.exe run_disjoint_multiseed.py 1 vibcur_6ch,cur_ABC,vib_XYZ
(~2-3 h per split seed with the 2-config default on an RTX 5070 Ti Laptop GPU)
"""
import sys, time, json, re, torch, numpy as np
sys.path.insert(0, '.')
import pandas as pd
from pathlib import Path
from collections import defaultdict
from torch.utils.data import TensorDataset, DataLoader
import torch.nn as nn
from config import DEVICE, NUM_CLASSES, MERGE_NAME, SCENARIOS, LABEL_MERGE, DATA_ROOT
from models import TinyCNN

# ---------------- settings ----------------
SEEDS = [42, 123, 456]
EPOCHS = 30
WINDOW, STEP = 2048, 1024
SCENARIO_LIST = ['leave_3000', 'leave_500']
CH_CONFIGS = {
    'vib_Z': [2], 'vib_XYZ': [0, 1, 2],
    'cur_ABC': [3, 4, 5], 'vibcur_6ch': [0, 1, 2, 3, 4, 5],
}
DIRECTIONS = [('A', 'B'), ('B', 'A')]
OUT = Path('../data/run_disjoint_multiseed_results.json')
STEADY_CSV = DATA_ROOT / 'steady_csv'

# ---------------- CLI: split seed + config subset ----------------
SPLIT_SEED = int(sys.argv[1]) if len(sys.argv) > 1 else 0
if len(sys.argv) > 2:
    CFG_LIST = sys.argv[2].split(',')
    for c in CFG_LIST:
        assert c in CH_CONFIGS, f'unknown config {c}'
else:
    # split 0 reruns the full 4-config grid; random partitions default to
    # the two extreme configs (full 6ch and current-only)
    CFG_LIST = list(CH_CONFIGS) if SPLIT_SEED == 0 else ['vibcur_6ch', 'cur_ABC']
print(f'Split seed = {SPLIT_SEED}, configs = {CFG_LIST}', flush=True)

# ---------------- filename parsing (same conventions as scripts/data_loader.py) ----------------
LABEL_MAP = {
    'health': 0,
    'bearing_inner_l': 1, 'bearing_inner_h': 2,
    'bearing_outer_l': 3, 'bearing_outer_h': 4,
    'bearing_ball': 5,
    'winding_l': 10, 'winding_h': 11,
    'static_eccentricity_l': 12, 'static_eccentricity_h': 13,
    'dynamic_eccentricity': 14,
    'broken_bar': 15,
    'voltage_unbalance': 16,
    'bend': 17,
}
ORIG_TO_CONTIGUOUS = {0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 10: 6, 11: 7,
                      12: 8, 13: 9, 14: 10, 15: 11, 16: 12, 17: 13}


def parse_steady_name(fname):
    """Steady segment filename -> (recording_id, domain, merged_label, torque) or None."""
    stem = Path(fname).stem.lower()
    if '_d_speed_' not in stem:
        return None
    if 'and' in stem:  # composite-fault file: skipped, as in the main protocol
        return None
    rec = stem.split('_d_speed_')[0]
    m = re.search(r'd_speed_(\d+)', stem)
    domain = int(m.group(1)) if m else -1
    m = re.search(r'(\d+)nm', stem)
    torque = int(m.group(1)) if m else -1
    label = -1
    for key, val in sorted(LABEL_MAP.items(), key=lambda x: -len(x[0])):
        if key in stem:
            label = val
            break
    if label < 0 or domain < 0:
        return None
    merged = LABEL_MERGE[ORIG_TO_CONTIGUOUS[label]]
    return rec, domain, merged, torque


# ---------------- index all steady files ----------------
print(f'Scanning {STEADY_CSV} ...', flush=True)
files = []
for f in sorted(STEADY_CSV.glob('*.csv')):
    p = parse_steady_name(f.name)
    if p is None:
        continue
    rec, domain, merged, torque = p
    files.append({'path': f, 'rec': rec, 'domain': domain,
                  'label': merged, 'torque': torque})
print(f'{len(files)} single-label steady segments, '
      f'{len({f["rec"] for f in files})} distinct recordings', flush=True)

# ---------------- leakage audit (standard split) ----------------
print('\n=== Leakage audit: recordings on BOTH sides of the standard split ===',
      flush=True)
for sc_name, sc in SCENARIOS.items():
    rec_src = {f['rec'] for f in files if f['domain'] in sc['source']}
    rec_tgt = {f['rec'] for f in files if f['domain'] in sc['target']}
    both = rec_src & rec_tgt
    print(f'  {sc_name:12s}: |src recs|={len(rec_src):3d}  |tgt recs|={len(rec_tgt):3d}  '
          f'overlap={len(both):3d}  ({100 * len(both) / max(len(rec_tgt), 1):.0f}% of target recs)',
          flush=True)

# ---------------- stratified recording split ----------------
def circ_rpm(rec):
    """Circulation top speed: the '<N>rpm' token before the 12-digit timestamp."""
    m = re.search(r'_(\d+)rpm_\d{12}$', rec)
    return int(m.group(1)) if m else -1


strata = defaultdict(list)
for rec in sorted({f['rec'] for f in files}):
    r0 = next(f for f in files if f['rec'] == rec)
    strata[(r0['label'], r0['torque'], circ_rpm(rec))].append(rec)

GROUP = {}
if SPLIT_SEED == 0:
    # deterministic phase-rotated assignment (backward compatible)
    for j, key in enumerate(sorted(strata)):
        for i, rec in enumerate(sorted(strata[key])):
            GROUP[rec] = 'A' if (i + j) % 2 == 0 else 'B'
else:
    # random partition: shuffle inside each stratum, random start phase, alternate
    rng = np.random.RandomState(SPLIT_SEED)
    for key in sorted(strata):
        recs = sorted(strata[key])
        rng.shuffle(recs)
        phase = int(rng.randint(2))
        for i, rec in enumerate(recs):
            GROUP[rec] = 'A' if (i + phase) % 2 == 0 else 'B'
nA = sum(1 for g in GROUP.values() if g == 'A')
mode = 'deterministic phase-rotated' if SPLIT_SEED == 0 else f'random (seed {SPLIT_SEED})'
print(f'\nRecording split [{mode}]: group A = {nA}, group B = {len(GROUP) - nA} '
      f'(stratified by class x torque x circulation speed)', flush=True)
for sc_name in SCENARIO_LIST:
    sc = SCENARIOS[sc_name]
    for g_src, g_tgt in DIRECTIONS:
        tgt_cls = sorted({f['label'] for f in files
                          if GROUP[f['rec']] == g_tgt and f['domain'] in sc['target']})
        src_cls = sorted({f['label'] for f in files
                          if GROUP[f['rec']] == g_src and f['domain'] in sc['source']})
        warn = '' if len(tgt_cls) == NUM_CLASSES else \
            f'  <-- WARNING: target side covers only {len(tgt_cls)}/{NUM_CLASSES} classes'
        print(f'  {sc_name:12s} {g_src}->{g_tgt}: src classes={len(src_cls)}, '
              f'tgt classes={len(tgt_cls)} {tgt_cls}{warn}', flush=True)

# ---------------- windowing (identical to scripts/cache_multichannel.py) ----------------
def window_files(file_list, tag):
    Xs, ys = [], []
    t0 = time.time()
    for i, meta in enumerate(file_list):
        df = pd.read_csv(meta['path'], header=None)
        sig = df.iloc[:, 3:9].values.astype(np.float32)  # cols 3-8: vib_XYZ, cur_ABC
        n = len(sig)
        for start in range(0, n - WINDOW + 1, STEP):
            w = sig[start:start + WINDOW]
            w = (w - w.mean(axis=0, keepdims=True)) / (w.std(axis=0, keepdims=True) + 1e-8)
            Xs.append(w.T)
        ys.extend([meta['label']] * ((n - WINDOW) // STEP + 1 if n >= WINDOW else 0))
        if (i + 1) % 50 == 0:
            print(f'    [{tag}] {i + 1}/{len(file_list)} files '
                  f'({time.time() - t0:.0f}s)', flush=True)
    if not Xs:
        return np.zeros((0, 6, WINDOW), dtype=np.float32), np.zeros(0, dtype=np.int64)
    X = np.stack(Xs).astype(np.float32)
    y = np.array(ys, dtype=np.int64)
    return X, y


# ---------------- training (identical to run_multi_seed.py) ----------------
def train_eval(X_src, y_src, X_tgt, y_tgt, ch_idx, seed):
    torch.manual_seed(seed); np.random.seed(seed)
    X_sc = torch.from_numpy(X_src[:, ch_idx, :]).float()
    X_tc = torch.from_numpy(X_tgt[:, ch_idx, :]).float()
    dl_src = DataLoader(TensorDataset(X_sc, torch.from_numpy(y_src).long()),
                        256, shuffle=True, drop_last=True, pin_memory=True)
    dl_tgt = DataLoader(TensorDataset(X_tc, torch.from_numpy(y_tgt).long()),
                        512, shuffle=False, pin_memory=True)
    model = TinyCNN(in_c=len(ch_idx), n_cls=NUM_CLASSES).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=EPOCHS)
    best, best_preds, best_labels = 0.0, None, None
    for ep in range(EPOCHS):
        model.train()
        for xb, yb in dl_src:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad(); nn.CrossEntropyLoss()(model(xb), yb).backward(); opt.step()
        sched.step()
        model.eval(); correct = 0; ap, al = [], []
        with torch.no_grad():
            for xb, yb in dl_tgt:
                p = model(xb.to(DEVICE)).argmax(1)
                correct += p.eq(yb.to(DEVICE)).sum().item()
                ap.append(p.cpu()); al.append(yb)
        acc = correct / len(dl_tgt.dataset)
        if acc > best:
            best = acc
            best_preds = torch.cat(ap).numpy(); best_labels = torch.cat(al).numpy()
    pc, pc_n = {}, {}
    for c in range(NUM_CLASSES):
        mask = best_labels == c
        tot = int(mask.sum())
        cor = int((best_preds[mask] == c).sum()) if tot > 0 else 0
        pc[MERGE_NAME[c]] = cor / tot if tot > 0 else 0.0
        pc_n[MERGE_NAME[c]] = [cor, tot]
    return best, pc, pc_n


# ---------------- main grid (resumable) ----------------
results = json.load(open(OUT)) if OUT.exists() else []
done = {(e.get('split', 0), e['scenario'], e['direction'], e['config'], e['seed'])
        for e in results}


def save():
    with open(OUT, 'w') as f:
        json.dump(results, f, indent=2)


t_start = time.time()
for sc_name in SCENARIO_LIST:
    sc = SCENARIOS[sc_name]
    for g_src, g_tgt in DIRECTIONS:
        direction = f'{g_src}->{g_tgt}'
        src_files = [f for f in files
                     if GROUP[f['rec']] == g_src and f['domain'] in sc['source']]
        tgt_files = [f for f in files
                     if GROUP[f['rec']] == g_tgt and f['domain'] in sc['target']]
        src_recs = len({f['rec'] for f in src_files})
        tgt_recs = len({f['rec'] for f in tgt_files})
        assert not ({f['rec'] for f in src_files} & {f['rec'] for f in tgt_files}), \
            'recording overlap detected!'
        if not tgt_files:
            print(f'\n{sc_name} {direction}: empty target side, skipped', flush=True)
            continue
        print(f'\n{"=" * 60}\n{sc_name} {direction}: '
              f'{len(src_files)} src segments ({src_recs} recs) -> '
              f'{len(tgt_files)} tgt segments ({tgt_recs} recs)', flush=True)
        X_src, y_src = window_files(src_files, f'{sc_name}/{direction} src')
        X_tgt, y_tgt = window_files(tgt_files, f'{sc_name}/{direction} tgt')
        print(f'  windows: src {X_src.shape}, tgt {X_tgt.shape}', flush=True)

        for cfg_name in CFG_LIST:
            ch_idx = CH_CONFIGS[cfg_name]
            for seed in SEEDS:
                if (SPLIT_SEED, sc_name, direction, cfg_name, seed) in done:
                    continue
                t0 = time.time()
                best, pc, pc_n = train_eval(X_src, y_src, X_tgt, y_tgt, ch_idx, seed)
                results.append({
                    'split': SPLIT_SEED,
                    'scenario': sc_name, 'direction': direction,
                    'config': cfg_name, 'seed': seed,
                    'best_acc': round(float(best) * 100, 2),
                    'per_class': {k: round(v * 100, 2) for k, v in pc.items()},
                    'per_class_n': pc_n,
                    'macro': round(float(np.mean(list(pc.values()))) * 100, 2),
                    'n_src_windows': int(len(y_src)), 'n_tgt_windows': int(len(y_tgt)),
                    'n_src_recs': src_recs, 'n_tgt_recs': tgt_recs,
                    'elapsed_s': round(time.time() - t0, 1)})
                save()
                print(f'  {cfg_name:12s} seed={seed}: {best * 100:.2f}% '
                      f'({time.time() - t0:.0f}s)', flush=True)
        del X_src, X_tgt, y_src, y_tgt  # free memory before next direction

print(f'\nAll done in {(time.time() - t_start) / 3600:.1f} h. '
      f'Results: {OUT} ({len(results)} runs)', flush=True)

# ---------------- summary: per split, per direction and pooled ----------------
print('\n=== Summary (mean +/- std over seeds) ===', flush=True)
splits_present = sorted({e.get('split', 0) for e in results})
for sp in splits_present:
    sp_results = [e for e in results if e.get('split', 0) == sp]
    print(f'\n--- split {sp} ---', flush=True)
    for sc_name in SCENARIO_LIST:
        for cfg_name in CH_CONFIGS:
            for direction in [f'{a}->{b}' for a, b in DIRECTIONS] + ['pooled']:
                if direction == 'pooled':
                    # pool both directions: every recording is tested exactly once
                    vals = []
                    for seed in SEEDS:
                        cor = sum(e['per_class_n'][k][0]
                                  for e in sp_results
                                  if e['scenario'] == sc_name and e['config'] == cfg_name
                                  and e['seed'] == seed
                                  for k in e['per_class_n'])
                        tot = sum(e['per_class_n'][k][1]
                                  for e in sp_results
                                  if e['scenario'] == sc_name and e['config'] == cfg_name
                                  and e['seed'] == seed
                                  for k in e['per_class_n'])
                        if tot:
                            vals.append(100.0 * cor / tot)
                else:
                    vals = [e['best_acc'] for e in sp_results
                            if e['scenario'] == sc_name and e['direction'] == direction
                            and e['config'] == cfg_name]
                if vals:
                    sd = np.std(vals, ddof=1) if len(vals) > 1 else 0.0
                    print(f'  {sc_name:12s} {direction:6s} {cfg_name:12s} '
                          f'{np.mean(vals):6.2f} +/- {sd:5.2f}  (n={len(vals)})', flush=True)

# ---------------- cross-split summary (pooled only) ----------------
if len(splits_present) > 1:
    print('\n=== Cross-split summary (pooled; mean over splits of seed-means) ===',
          flush=True)
    for sc_name in SCENARIO_LIST:
        for cfg_name in CH_CONFIGS:
            split_means = []
            for sp in splits_present:
                vals = []
                for seed in SEEDS:
                    cor = sum(e['per_class_n'][k][0]
                              for e in results
                              if e.get('split', 0) == sp and e['scenario'] == sc_name
                              and e['config'] == cfg_name and e['seed'] == seed
                              for k in e['per_class_n'])
                    tot = sum(e['per_class_n'][k][1]
                              for e in results
                              if e.get('split', 0) == sp and e['scenario'] == sc_name
                              and e['config'] == cfg_name and e['seed'] == seed
                              for k in e['per_class_n'])
                    if tot:
                        vals.append(100.0 * cor / tot)
                if vals:
                    split_means.append(np.mean(vals))
            if len(split_means) > 1:
                sd = np.std(split_means, ddof=1)
                print(f'  {sc_name:12s} {cfg_name:12s} '
                      f'{np.mean(split_means):6.2f} +/- {sd:5.2f} across splits '
                      f'{[round(float(v), 2) for v in split_means]}', flush=True)
