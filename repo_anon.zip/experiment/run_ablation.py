"""
Channel ablation: 6 configurations × 4 scenarios.
Saves timestamped results for reproducibility audit.
"""
import time, json, os, sys
from datetime import datetime

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import TensorDataset, DataLoader

# Ensure MCC5_ROOT is set (MCC5_ROOT默认值已在config.py中处理)
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from config import DEVICE, NUM_CLASSES, SCENARIOS
from data import load_domains, select_channels
from models import TinyCNN

def train_ablation(X_src, y_src, X_tgt, y_tgt, in_c, epochs=25, seed=42):
    """Train a single TinyCNN model and return best target accuracy."""
    torch.manual_seed(seed)
    np.random.seed(seed)

    ds_src = TensorDataset(torch.from_numpy(X_src).float(), torch.from_numpy(y_src).long())
    ds_tgt = TensorDataset(torch.from_numpy(X_tgt).float(), torch.from_numpy(y_tgt).long())
    src_loader = DataLoader(ds_src, 256, shuffle=True, drop_last=True, pin_memory=True)
    tgt_loader = DataLoader(ds_tgt, 512, shuffle=False, pin_memory=True)

    model = TinyCNN(in_c=in_c, n_cls=NUM_CLASSES).to(DEVICE)
    opt = torch.optim.AdamW(model.parameters(), lr=5e-4, weight_decay=1e-4)
    crit = nn.CrossEntropyLoss()
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=epochs)
    best_acc = 0.0

    for ep in range(epochs):
        model.train()
        for xb, yb in src_loader:
            xb, yb = xb.to(DEVICE), yb.to(DEVICE)
            opt.zero_grad()
            crit(model(xb), yb).backward()
            opt.step()
        sched.step()

        if (ep + 1) % 5 == 0 or ep == epochs - 1:
            model.eval()
            correct = 0
            total = 0
            with torch.no_grad():
                for xb, yb in tgt_loader:
                    pred = model(xb.to(DEVICE)).argmax(1)
                    correct += pred.eq(yb.to(DEVICE)).sum().item()
                    total += len(yb)
            best_acc = max(best_acc, correct / total)

    return float(best_acc)

# Channel configurations: (name, channel_indices, n_channels)
CHANNELS = [
    ('vib_Z',        [2],           1),
    ('vib_XY',       [0, 1],        2),
    ('vib_XYZ',      [0, 1, 2],     3),
    ('cur_ABC',      [3, 4, 5],     3),
    ('vib_XYZ_curA', [0, 1, 2, 3],  4),
    ('vibcur_6ch',   [0, 1, 2, 3, 4, 5], 6),
]

if __name__ == '__main__':
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    all_results = {}
    total_start = time.time()

    for sname, spec in SCENARIOS.items():
        src_domains = spec['source']
        tgt_domains = spec['target']
        print(f"\n{'='*60}")
        print(f"[{timestamp}] SCENARIO: {sname}  |  Source: {src_domains}  Target: {tgt_domains}")

        X_all_src, y_src = load_domains(src_domains)
        X_all_tgt, y_tgt = load_domains(tgt_domains)
        print(f"  Data: src={len(y_src):,d}  tgt={len(y_tgt):,d}")

        for ch_name, ch_idx, nch in CHANNELS:
            t0 = time.time()
            X_sc = select_channels(X_all_src, ch_idx)
            X_tc = select_channels(X_all_tgt, ch_idx)

            acc = train_ablation(X_sc, y_src, X_tc, y_tgt, in_c=nch, seed=42)
            elapsed = time.time() - t0

            print(f"  [{ch_name:>14s}] acc={acc*100:.2f}%  ({elapsed:.0f}s)")

            key = f'{sname}_{ch_name}'
            all_results[key] = {
                'scenario': sname,
                'channels': ch_name,
                'best_acc': acc,
                'seed': 42,
                'elapsed_s': round(elapsed, 1),
                'timestamp': timestamp,
            }

        # Save intermediate after each scenario
        tmp_path = os.path.join(os.path.dirname(__file__), f'results_ablation_{timestamp}.json')
        with open(tmp_path, 'w') as f:
            json.dump(all_results, f, indent=2)

    total_time = time.time() - total_start
    print(f"\n{'='*60}")
    print(f"Total: {total_time/60:.1f} min")
    print(f"Results saved to: results_ablation_{timestamp}.json")

    # Print summary table
    print(f"\n{'='*70}")
    print("ABLATION RESULTS (new run)")
    print(f"{'Channels':<20s} {'leave_3000':>10s} {'leave_500':>10s} {'lo→hi':>8s} {'hi→lo':>8s} {'Avg':>8s}")
    print('-' * 70)
    for ch_name, _, _ in CHANNELS:
        row = f"{ch_name:<20s}"
        accs = []
        for sname in SCENARIOS:
            k = f'{sname}_{ch_name}'
            acc = all_results.get(k, {}).get('best_acc', 0)
            row += f" {acc*100:>8.1f}%"
            accs.append(acc)
        row += f" {np.mean(accs)*100:>7.1f}%"
        print(row)
